-- Barangay Database Backup
-- Database: barangay
-- Backup Type: manual
-- Created: 2025-06-06 14:58:56
-- Tables: 83

SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------
-- Table structure for `addresses`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `barangay_id` int DEFAULT NULL,
  `barangay_name` varchar(60) DEFAULT NULL,
  `house_no` varchar(50) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `phase` varchar(50) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT 'SAN RAFAEL',
  `province` varchar(100) DEFAULT 'BULACAN',
  `region` varchar(50) DEFAULT 'III',
  `subdivision` varchar(100) DEFAULT NULL,
  `block_lot` varchar(50) DEFAULT NULL,
  `residency_type` enum('Home Owner','Renter','Boarder','Living-In') NOT NULL,
  `years_in_san_rafael` int DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT '1',
  `is_permanent` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `user_id` (`user_id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `addresses_ibfk_3` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `addresses`
--
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', NULL, NULL, '101', '1', '0', '1', 'SAN RAFAEL', '10', NULL, 'BULACAN', 'III', 'Home Owner', 'Mabini Extension', NULL, NULL, '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', NULL, NULL, '202', '2', '0', '1', 'SAN RAFAEL', '11', NULL, 'BULACAN', 'III', 'Home Owner', 'Rizal Street', NULL, NULL, '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', NULL, NULL, '303', '3', '0', '1', 'SAN RAFAEL', '12', NULL, 'BULACAN', 'III', 'Home Owner', 'Rivera Compound', NULL, NULL, '25');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('18', NULL, NULL, '456', '4', '0', '1', 'SAN RAFAEL', '13', NULL, 'BULACAN', 'III', 'Renter', 'Rizal Avenue', NULL, NULL, '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', NULL, NULL, '789', '5', '0', '1', 'SAN RAFAEL', '14', NULL, 'BULACAN', 'III', 'Home Owner', 'Luna Street', NULL, NULL, '20');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', NULL, NULL, '321', '6', '0', '1', 'SAN RAFAEL', '15', NULL, 'BULACAN', 'III', 'Boarder', 'Bonifacio Road', NULL, NULL, '3');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('18', NULL, NULL, '654', '7', '0', '1', 'SAN RAFAEL', '16', NULL, 'BULACAN', 'III', 'Home Owner', 'Aguinaldo Street', NULL, NULL, '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '15', '8', '0', '1', 'SAN RAFAEL', '18', 'Phase 1', 'BULACAN', 'III', 'Home Owner', 'Mabini Street', NULL, '11', '15');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '22', '9', '0', '1', 'SAN RAFAEL', '19', 'Phase 2', 'BULACAN', 'III', 'Home Owner', 'Rizal Avenue', NULL, '12', '18');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '8', '10', '0', '1', 'SAN RAFAEL', '20', 'Phase 1', 'BULACAN', 'III', 'Renter', 'Bonifacio Road', NULL, '13', '10');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '31', '11', '0', '1', 'SAN RAFAEL', '21', 'Phase 3', 'BULACAN', 'III', 'Home Owner', 'Luna Street', NULL, '14', '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '45', '12', '0', '1', 'SAN RAFAEL', '22', 'Phase 2', 'BULACAN', 'III', 'Renter', 'Aguinaldo Street', NULL, '15', '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '12', '13', '0', '1', 'SAN RAFAEL', '23', 'Purok A', 'BULACAN', 'III', 'Home Owner', 'Bayanihan Street', NULL, '16', '20');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '28', '14', '0', '1', 'SAN RAFAEL', '24', 'Purok B', 'BULACAN', 'III', 'Home Owner', 'Kamatayan Road', NULL, '17', '16');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '7', '15', '0', '1', 'SAN RAFAEL', '25', 'Purok A', 'BULACAN', 'III', 'Boarder', 'Sampaguita Street', NULL, '18', '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '19', '16', '0', '1', 'SAN RAFAEL', '26', 'Purok C', 'BULACAN', 'III', 'Home Owner', 'Maharlika Highway', NULL, '19', '22');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '33', '17', '0', '1', 'SAN RAFAEL', '27', 'Purok B', 'BULACAN', 'III', 'Renter', 'Narra Street', NULL, '20', '6');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '101', '18', '0', '1', 'SAN RAFAEL', '28', NULL, 'BULACAN', 'III', 'Home Owner', 'Mabini Extension', NULL, '21', '25');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '202', '19', '0', '1', 'SAN RAFAEL', '29', NULL, 'BULACAN', 'III', 'Home Owner', 'Rizal Street', NULL, '22', '20');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '55', '20', '0', '1', 'SAN RAFAEL', '30', 'Phase 4', 'BULACAN', 'III', 'Home Owner', 'Rivera Compound', NULL, '23', '45');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '78', '21', '0', '1', 'SAN RAFAEL', '31', 'Phase 5', 'BULACAN', 'III', 'Renter', 'Santos Street', NULL, '24', '18');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '92', '22', '0', '1', 'SAN RAFAEL', '32', 'Phase 3', 'BULACAN', 'III', 'Home Owner', 'Mendoza Avenue', NULL, '25', '15');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '456', '23', '0', '1', 'SAN RAFAEL', '33', 'Purok C', 'BULACAN', 'III', 'Home Owner', 'Maligaya Street', NULL, '26', '22');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '67', '24', '0', '1', 'SAN RAFAEL', '34', 'Purok D', 'BULACAN', 'III', 'Home Owner', 'Engineers Village', NULL, '27', '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '23', '25', '0', '1', 'SAN RAFAEL', '35', 'Purok A', 'BULACAN', 'III', 'Home Owner', 'Flores Compound', NULL, '28', '35');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '89', '26', '0', '1', 'SAN RAFAEL', '36', 'Purok B', 'BULACAN', 'III', 'Boarder', 'Security Village', NULL, '29', '10');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '134', '27', '0', '1', 'SAN RAFAEL', '37', 'Purok C', 'BULACAN', 'III', 'Renter', 'Medical Center Road', NULL, '30', '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '44', '28', '0', '1', 'SAN RAFAEL', '38', 'Phase 1', 'BULACAN', 'III', 'Home Owner', 'Senior Street', NULL, NULL, '50');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '66', '29', '0', '1', 'SAN RAFAEL', '39', 'Phase 2', 'BULACAN', 'III', 'Home Owner', 'Carpenter Lane', NULL, NULL, '40');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '88', '30', '0', '1', 'SAN RAFAEL', '40', 'Phase 3', 'BULACAN', 'III', 'Home Owner', 'Housewife Street', NULL, NULL, '38');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '111', '31', '0', '1', 'SAN RAFAEL', '41', 'Phase 4', 'BULACAN', 'III', 'Renter', 'Construction Road', NULL, NULL, '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '133', '32', '0', '1', 'SAN RAFAEL', '42', 'Phase 5', 'BULACAN', 'III', 'Home Owner', 'Health Worker Lane', NULL, NULL, '25');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '77', '33', '0', '1', 'SAN RAFAEL', '43', 'Purok A', 'BULACAN', 'III', 'Home Owner', 'Driver Avenue', NULL, NULL, '35');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '99', '34', '0', '1', 'SAN RAFAEL', '44', 'Purok B', 'BULACAN', 'III', 'Home Owner', 'Esperanza Street', NULL, NULL, '33');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '122', '35', '0', '1', 'SAN RAFAEL', '45', 'Purok C', 'BULACAN', 'III', 'Home Owner', 'Electrician Road', NULL, NULL, '18');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '155', '36', '0', '1', 'SAN RAFAEL', '46', 'Purok D', 'BULACAN', 'III', 'Renter', 'Bank Street', NULL, NULL, '8');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '177', '37', '0', '1', 'SAN RAFAEL', '47', 'Purok A', 'BULACAN', 'III', 'Home Owner', 'Fisherman Lane', NULL, NULL, '28');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '101', '38', '0', '1', 'SAN RAFAEL', '48', NULL, 'BULACAN', 'III', 'Living-In', 'Mabini Extension', NULL, NULL, '14');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '202', '39', '0', '1', 'SAN RAFAEL', '49', NULL, 'BULACAN', 'III', 'Living-In', 'Rizal Street', NULL, NULL, '12');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '55', '40', '0', '1', 'SAN RAFAEL', '50', 'Phase 4', 'BULACAN', 'III', 'Living-In', 'Rivera Compound', NULL, NULL, '9');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('32', 'Tambubong', NULL, '78', '41', '0', '1', 'SAN RAFAEL', '51', 'Phase 5', 'BULACAN', 'III', 'Living-In', 'Santos Street', NULL, NULL, '16');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '456', '42', '0', '1', 'SAN RAFAEL', '52', 'Purok C', 'BULACAN', 'III', 'Living-In', 'Maligaya Street', NULL, NULL, '13');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '67', '43', '0', '1', 'SAN RAFAEL', '53', 'Purok D', 'BULACAN', 'III', 'Living-In', 'Engineers Village', NULL, NULL, '11');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '89', '44', '0', '1', 'SAN RAFAEL', '54', 'Purok B', 'BULACAN', 'III', 'Living-In', 'Security Village', NULL, NULL, '15');
INSERT INTO `addresses` (`barangay_id`, `barangay_name`, `block_lot`, `house_no`, `id`, `is_permanent`, `is_primary`, `municipality`, `person_id`, `phase`, `province`, `region`, `residency_type`, `street`, `subdivision`, `user_id`, `years_in_san_rafael`) VALUES('3', 'Caingin', NULL, '177', '45', '0', '1', 'SAN RAFAEL', '55', 'Purok A', 'BULACAN', 'III', 'Living-In', 'Fisherman Lane', NULL, NULL, '8');

-- --------------------------------------------------------
-- Table structure for `asset_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `asset_types`;
CREATE TABLE `asset_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `asset_types`
--
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '1', 'House');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '2', 'House & Lot');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '3', 'Farmland');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '4', 'Commercial Building');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '5', 'Lot');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '6', 'Fishpond/Resort');
INSERT INTO `asset_types` (`description`, `id`, `name`) VALUES(NULL, '7', 'Others');

-- --------------------------------------------------------
-- Table structure for `assets_properties`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `assets_properties`;
CREATE TABLE `assets_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `house` tinyint(1) DEFAULT '0',
  `house_lot` tinyint(1) DEFAULT '0',
  `farmland` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `assets_properties_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `audit_trails`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `audit_trails`;
CREATE TABLE `audit_trails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `admin_user_id` int DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` varchar(100) DEFAULT NULL,
  `old_values` text,
  `new_values` text,
  `description` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `action_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_trails_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `audit_trails`
--
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('LOGIN', NULL, 'User logged into the system', '1', NULL, NULL, NULL, '3', 'users', NULL, '3');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('VIEW', NULL, 'Viewed document request details', '2', NULL, NULL, NULL, '1', 'document_requests', NULL, '3');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('EXPORT', NULL, 'Exported audit trail report', '3', NULL, NULL, NULL, 'ALL', 'audit_trails', NULL, '3');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('FILTER', NULL, 'Applied filters to audit trail view', '4', NULL, NULL, NULL, 'ALL', 'audit_trails', NULL, '3');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('APPROVE', NULL, 'Approved barangay clearance for Juan Santos', '5', '192.168.1.101', NULL, NULL, '7', 'document_requests', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '11');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('CREATE', NULL, 'New proof of residency request from Maria Garcia', '6', '192.168.1.101', NULL, NULL, '8', 'document_requests', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '11');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('COMPLETE', NULL, 'Completed indigency certificate for Carmen Flores', '7', '192.168.1.102', NULL, NULL, '13', 'document_requests', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '16');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('CREATE', NULL, 'Filed new noise complaint case', '8', '192.168.1.103', NULL, NULL, '5', 'blotter_cases', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '9');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('SCHEDULE', NULL, 'Scheduled hearing for karaoke noise case', '9', '192.168.1.103', NULL, NULL, '5', 'blotter_cases', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '9');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('RESOLVE', NULL, 'Resolved construction noise case through mediation', '10', '192.168.1.104', NULL, NULL, '10', 'blotter_cases', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '19');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('ASSIGN', NULL, 'Assigned assault case for investigation', '11', '192.168.1.104', NULL, NULL, '13', 'blotter_cases', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '19');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('CREATE', NULL, 'Created new resident account for Carlos Mendoza', '12', '192.168.1.100', NULL, NULL, '25', 'users', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '1');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('UPDATE', NULL, 'Updated role assignment for health worker', '13', '192.168.1.100', NULL, NULL, '15', 'user_roles', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '2');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('CREATE', NULL, 'Created Monthly Cleanup Drive event', '14', '192.168.1.101', NULL, NULL, '5', 'events', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '11');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('CREATE', NULL, 'Created Senior Citizens Health Fair', '15', '192.168.1.105', NULL, NULL, '6', 'events', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '15');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('UPDATE', NULL, 'Updated Farmers Market event details', '16', '192.168.1.102', NULL, NULL, '10', 'events', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '16');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('EXPORT', NULL, 'Exported monthly document requests report', '17', '192.168.1.106', NULL, NULL, 'ALL', 'document_requests', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '4');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('EXPORT', NULL, 'Exported quarterly blotter cases report', '18', '192.168.1.107', NULL, NULL, 'ALL', 'blotter_cases', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '8');
INSERT INTO `audit_trails` (`action`, `admin_user_id`, `description`, `id`, `ip_address`, `new_values`, `old_values`, `record_id`, `table_name`, `user_agent`, `user_id`) VALUES('VIEW', NULL, 'Reviewed system audit logs', '19', '192.168.1.100', NULL, NULL, 'ALL', 'audit_trails', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '2');

-- --------------------------------------------------------
-- Table structure for `backup_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `backup_settings`
--
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('1', 'auto_backup_enabled', '1');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('2', 'daily_backup_enabled', '1');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('3', 'weekly_backup_enabled', '1');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('4', 'monthly_backup_enabled', '1');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('5', 'daily_retention_days', '7');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('6', 'weekly_retention_weeks', '4');
INSERT INTO `backup_settings` (`id`, `setting_key`, `setting_value`) VALUES('7', 'monthly_retention_months', '12');

-- --------------------------------------------------------
-- Table structure for `barangay`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `barangay`;
CREATE TABLE `barangay` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barangay`
--
INSERT INTO `barangay` (`id`, `name`) VALUES('2', 'Banca‐Banca');
INSERT INTO `barangay` (`id`, `name`) VALUES('1', 'BMA-Balagtas');
INSERT INTO `barangay` (`id`, `name`) VALUES('3', 'Caingin');
INSERT INTO `barangay` (`id`, `name`) VALUES('4', 'Capihan');
INSERT INTO `barangay` (`id`, `name`) VALUES('5', 'Coral na Bato');
INSERT INTO `barangay` (`id`, `name`) VALUES('6', 'Cruz na Daan');
INSERT INTO `barangay` (`id`, `name`) VALUES('7', 'Dagat‐Dagatan');
INSERT INTO `barangay` (`id`, `name`) VALUES('8', 'Diliman I');
INSERT INTO `barangay` (`id`, `name`) VALUES('9', 'Diliman II');
INSERT INTO `barangay` (`id`, `name`) VALUES('10', 'Libis');
INSERT INTO `barangay` (`id`, `name`) VALUES('11', 'Lico');
INSERT INTO `barangay` (`id`, `name`) VALUES('12', 'Maasim');
INSERT INTO `barangay` (`id`, `name`) VALUES('13', 'Mabalas‐Balas');
INSERT INTO `barangay` (`id`, `name`) VALUES('14', 'Maguinao');
INSERT INTO `barangay` (`id`, `name`) VALUES('15', 'Maronquillo');
INSERT INTO `barangay` (`id`, `name`) VALUES('16', 'Paco');
INSERT INTO `barangay` (`id`, `name`) VALUES('17', 'Pansumaloc');
INSERT INTO `barangay` (`id`, `name`) VALUES('18', 'Pantubig');
INSERT INTO `barangay` (`id`, `name`) VALUES('19', 'Pasong Bangkal');
INSERT INTO `barangay` (`id`, `name`) VALUES('20', 'Pasong Callos');
INSERT INTO `barangay` (`id`, `name`) VALUES('21', 'Pasong Intsik');
INSERT INTO `barangay` (`id`, `name`) VALUES('22', 'Pinacpinacan');
INSERT INTO `barangay` (`id`, `name`) VALUES('23', 'Poblacion');
INSERT INTO `barangay` (`id`, `name`) VALUES('24', 'Pulo');
INSERT INTO `barangay` (`id`, `name`) VALUES('25', 'Pulong Bayabas');
INSERT INTO `barangay` (`id`, `name`) VALUES('26', 'Salapungan');
INSERT INTO `barangay` (`id`, `name`) VALUES('27', 'Sampaloc');
INSERT INTO `barangay` (`id`, `name`) VALUES('28', 'San Agustin');
INSERT INTO `barangay` (`id`, `name`) VALUES('29', 'San Roque');
INSERT INTO `barangay` (`id`, `name`) VALUES('30', 'Sapang Pahalang');
INSERT INTO `barangay` (`id`, `name`) VALUES('31', 'Talacsan');
INSERT INTO `barangay` (`id`, `name`) VALUES('32', 'Tambubong');
INSERT INTO `barangay` (`id`, `name`) VALUES('33', 'Tukod');
INSERT INTO `barangay` (`id`, `name`) VALUES('34', 'Ulingao');

-- --------------------------------------------------------
-- Table structure for `barangay_document_prices`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `barangay_document_prices`;
CREATE TABLE `barangay_document_prices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `document_type_id` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barangay_document` (`barangay_id`,`document_type_id`),
  KEY `document_type_id` (`document_type_id`),
  CONSTRAINT `barangay_document_prices_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `barangay_document_prices_ibfk_2` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `barangay_paymongo_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `barangay_paymongo_settings`;
CREATE TABLE `barangay_paymongo_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `public_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `webhook_secret` varchar(255) DEFAULT NULL,
  `test_mode` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barangay_id` (`barangay_id`),
  CONSTRAINT `barangay_paymongo_settings_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `barangay_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `barangay_settings`;
CREATE TABLE `barangay_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `cutoff_time` time NOT NULL DEFAULT '15:00:00',
  `opening_time` time NOT NULL DEFAULT '08:00:00',
  `closing_time` time NOT NULL DEFAULT '17:00:00',
  `barangay_captain_name` varchar(100) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `local_barangay_contact` varchar(20) DEFAULT NULL,
  `pnp_contact` varchar(20) DEFAULT NULL,
  `bfp_contact` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `barangay_settings_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barangay_settings`
--
INSERT INTO `barangay_settings` (`barangay_captain_name`, `barangay_id`, `bfp_contact`, `closing_time`, `contact_number`, `cutoff_time`, `email`, `id`, `local_barangay_contact`, `opening_time`, `pnp_contact`) VALUES('Juan Dela Cruz', '32', '0917-555-9012', '17:00:00', NULL, '15:00:00', NULL, '1', '0917-555-1234', '08:00:00', '0917-555-5678');
INSERT INTO `barangay_settings` (`barangay_captain_name`, `barangay_id`, `bfp_contact`, `closing_time`, `contact_number`, `cutoff_time`, `email`, `id`, `local_barangay_contact`, `opening_time`, `pnp_contact`) VALUES('Maria Santos', '18', '0917-555-2109', '17:00:00', NULL, '15:00:00', NULL, '2', '0917-555-4321', '08:00:00', '0917-555-8765');
INSERT INTO `barangay_settings` (`barangay_captain_name`, `barangay_id`, `bfp_contact`, `closing_time`, `contact_number`, `cutoff_time`, `email`, `id`, `local_barangay_contact`, `opening_time`, `pnp_contact`) VALUES('Roberto Reyes', '3', '0917-555-5566', '17:00:00', NULL, '15:00:00', NULL, '3', '0917-555-1122', '08:00:00', '0917-555-3344');
INSERT INTO `barangay_settings` (`barangay_captain_name`, `barangay_id`, `bfp_contact`, `closing_time`, `contact_number`, `cutoff_time`, `email`, `id`, `local_barangay_contact`, `opening_time`, `pnp_contact`) VALUES('Ricardo Morales', '1', '0917-555-2468', '17:00:00', NULL, '15:00:00', NULL, '4', '0917-555-7890', '08:00:00', '0917-555-1357');

-- --------------------------------------------------------
-- Table structure for `blotter_case_categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `blotter_case_categories`;
CREATE TABLE `blotter_case_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `category_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_category` (`blotter_case_id`,`category_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `blotter_case_categories_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blotter_case_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `case_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blotter_case_categories`
--
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('1', '8', '1');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('2', '8', '2');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('3', '8', '3');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('4', '8', '4');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('5', '8', '5');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('6', '8', '6');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('7', '1', '7');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('8', '8', '8');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('9', '8', '9');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('10', '8', '10');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('11', '8', '11');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('12', '8', '12');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('13', '8', '13');
INSERT INTO `blotter_case_categories` (`blotter_case_id`, `category_id`, `id`) VALUES('14', '8', '14');

-- --------------------------------------------------------
-- Table structure for `blotter_case_interventions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `blotter_case_interventions`;
CREATE TABLE `blotter_case_interventions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `intervention_id` int NOT NULL,
  `intervened_at` datetime NOT NULL,
  `performed_by` varchar(100) DEFAULT NULL,
  `remarks` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_intervention_date` (`blotter_case_id`,`intervention_id`,`intervened_at`),
  KEY `intervention_id` (`intervention_id`),
  CONSTRAINT `blotter_case_interventions_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blotter_case_interventions_ibfk_2` FOREIGN KEY (`intervention_id`) REFERENCES `case_interventions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `blotter_cases`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `blotter_cases`;
CREATE TABLE `blotter_cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_number` varchar(50) DEFAULT NULL,
  `incident_date` datetime DEFAULT NULL,
  `filing_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `location` varchar(200) DEFAULT NULL,
  `description` text,
  `status` enum('pending','open','closed','completed','transferred','solved','endorsed_to_court','cfa_eligible','dismissed','deleted') DEFAULT 'pending',
  `scheduling_status` enum('none','pending_schedule','schedule_proposed','schedule_confirmed','scheduled','completed','cancelled','cfa_pending_issuance') DEFAULT 'none',
  `barangay_id` int DEFAULT NULL,
  `reported_by_person_id` int DEFAULT NULL,
  `assigned_to_user_id` int DEFAULT NULL,
  `accepted_by_user_id` int DEFAULT NULL,
  `accepted_by_role_id` int DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `scheduled_hearing` datetime DEFAULT NULL,
  `resolution_details` text,
  `resolved_at` datetime DEFAULT NULL,
  `dismissed_by_user_id` int DEFAULT NULL,
  `dismissal_reason` text,
  `dismissal_date` datetime DEFAULT NULL,
  `is_cfa_eligible` tinyint(1) DEFAULT '0',
  `cfa_reason` varchar(255) DEFAULT NULL COMMENT 'Reason why the case became CFA eligible',
  `cfa_issued_at` datetime DEFAULT NULL,
  `endorsed_to_court_at` datetime DEFAULT NULL,
  `hearing_count` int DEFAULT '0',
  `max_hearing_attempts` int DEFAULT '3',
  `requires_dual_signature` tinyint(1) DEFAULT '0',
  `captain_signature_date` datetime DEFAULT NULL,
  `chief_signature_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scheduling_deadline` datetime GENERATED ALWAYS AS ((`filing_date` + interval 5 day)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `case_number` (`case_number`),
  KEY `barangay_id` (`barangay_id`),
  KEY `reported_by_person_id` (`reported_by_person_id`),
  KEY `assigned_to_user_id` (`assigned_to_user_id`),
  KEY `idx_blotter_cases_dismissed` (`dismissed_by_user_id`,`dismissal_date`),
  KEY `accepted_by_user_id` (`accepted_by_user_id`),
  KEY `accepted_by_role_id` (`accepted_by_role_id`),
  CONSTRAINT `blotter_cases_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blotter_cases_ibfk_2` FOREIGN KEY (`reported_by_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blotter_cases_ibfk_3` FOREIGN KEY (`assigned_to_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blotter_cases_ibfk_4` FOREIGN KEY (`dismissed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blotter_cases_ibfk_5` FOREIGN KEY (`accepted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blotter_cases_ibfk_6` FOREIGN KEY (`accepted_by_role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blotter_cases`
--
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '32', NULL, 'TAM-2024-0001', NULL, NULL, NULL, 'Noise complaint against neighbor', NULL, NULL, NULL, NULL, '0', '1', '2024-01-15 14:30:00', '0', 'Mabini Street, Tambubong', '3', '10', '0', NULL, NULL, NULL, 'pending_schedule', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '18', NULL, 'PAN-2024-0001', NULL, NULL, NULL, 'Property boundary dispute', NULL, NULL, NULL, NULL, '0', '2', '2024-01-20 09:15:00', '0', 'Rizal Avenue, Pantubig', '3', '11', '0', NULL, NULL, NULL, 'pending_schedule', 'pending');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '3', NULL, 'CAI-2024-0001', NULL, NULL, NULL, 'Family dispute mediation', NULL, NULL, NULL, NULL, '0', '3', '2024-01-25 16:45:00', '0', 'Luna Street, Caingin', '3', '12', '0', NULL, NULL, NULL, 'none', 'closed');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '32', NULL, 'TAM-2024-0002', NULL, NULL, NULL, 'Property damage complaint', NULL, NULL, NULL, NULL, '0', '4', '2024-02-10 20:00:00', '0', 'Rizal Street, Tambubong', '3', '11', '0', NULL, NULL, NULL, 'pending_schedule', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '9', '32', NULL, 'TAM-2024-003', NULL, NULL, NULL, 'Loud music complaint - neighbor playing karaoke past 10 PM during weekdays', NULL, NULL, NULL, NULL, '0', '5', '2024-02-01 20:30:00', '0', 'Mabini Extension, Tambubong', '3', '28', '0', NULL, NULL, NULL, 'none', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '32', NULL, 'TAM-2024-004', NULL, NULL, NULL, 'Property boundary dispute - fence allegedly built on neighboring lot', NULL, NULL, NULL, NULL, '0', '6', '2024-02-05 14:15:00', '0', 'Rizal Street, Tambubong', '3', '29', '1', NULL, NULL, NULL, 'none', 'pending');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '9', '32', NULL, 'TAM-2024-005', NULL, NULL, NULL, 'Domestic violence case - husband physically abusing wife', NULL, NULL, NULL, NULL, '0', '7', '2024-02-08 16:45:00', '0', 'Santos Street, Tambubong', '3', '31', '1', NULL, NULL, NULL, 'none', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '32', NULL, 'TAM-2024-006', NULL, NULL, NULL, 'Theft complaint - motorcycle parts stolen from repair shop', NULL, NULL, NULL, NULL, '0', '8', '2024-02-10 09:20:00', '0', 'Mendoza Avenue, Tambubong', '3', '32', '0', NULL, NULL, NULL, 'none', 'pending');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '9', '32', NULL, 'TAM-2024-007', NULL, NULL, NULL, 'Elder abuse case - son neglecting elderly mother, not providing proper care', NULL, NULL, NULL, NULL, '0', '9', '2024-02-12 18:30:00', '0', 'Senior Street, Tambubong', '3', '38', '1', NULL, NULL, NULL, 'none', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '19', '3', NULL, 'CAI-2024-002', NULL, NULL, NULL, 'Noise disturbance - construction work during prohibited hours', NULL, NULL, NULL, NULL, '0', '10', '2024-02-03 21:00:00', '0', 'Maligaya Street, Caingin', '3', '33', '0', NULL, NULL, NULL, 'none', 'completed');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '19', '3', NULL, 'CAI-2024-003', NULL, NULL, NULL, 'Parking dispute - neighbor blocking driveway access', NULL, NULL, NULL, NULL, '0', '11', '2024-02-06 13:45:00', '0', 'Engineers Village, Caingin', '3', '34', '0', NULL, NULL, NULL, 'none', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '3', NULL, 'CAI-2024-004', NULL, NULL, NULL, 'Family dispute - inheritance conflict between siblings', NULL, NULL, NULL, NULL, '0', '12', '2024-02-09 19:20:00', '0', 'Flores Compound, Caingin', '3', '35', '1', NULL, NULL, NULL, 'none', 'pending');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, '19', '3', NULL, 'CAI-2024-005', NULL, NULL, NULL, 'Assault case - physical altercation between neighbors', NULL, NULL, NULL, NULL, '0', '13', '2024-02-11 15:30:00', '0', 'Security Village, Caingin', '3', '36', '1', NULL, NULL, NULL, 'none', 'open');
INSERT INTO `blotter_cases` (`accepted_at`, `accepted_by_role_id`, `accepted_by_user_id`, `assigned_to_user_id`, `barangay_id`, `captain_signature_date`, `case_number`, `cfa_issued_at`, `cfa_reason`, `chief_signature_date`, `description`, `dismissal_date`, `dismissal_reason`, `dismissed_by_user_id`, `endorsed_to_court_at`, `hearing_count`, `id`, `incident_date`, `is_cfa_eligible`, `location`, `max_hearing_attempts`, `reported_by_person_id`, `requires_dual_signature`, `resolution_details`, `resolved_at`, `scheduled_hearing`, `scheduling_status`, `status`) VALUES(NULL, NULL, NULL, NULL, '3', NULL, 'CAI-2024-006', NULL, NULL, NULL, 'Animal complaint - rooster causing disturbance early morning', NULL, NULL, NULL, NULL, '0', '14', '2024-02-13 11:15:00', '0', 'Driver Avenue, Caingin', '3', '43', '0', NULL, NULL, NULL, 'none', 'pending');

-- --------------------------------------------------------
-- Table structure for `blotter_participants`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `blotter_participants`;
CREATE TABLE `blotter_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `person_id` int DEFAULT NULL,
  `external_participant_id` int DEFAULT NULL,
  `role` enum('complainant','respondent','witness') NOT NULL,
  `statement` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_person_role` (`blotter_case_id`,`person_id`,`role`),
  UNIQUE KEY `uk_case_external_role` (`blotter_case_id`,`external_participant_id`,`role`),
  KEY `person_id` (`person_id`),
  KEY `external_participant_id` (`external_participant_id`),
  CONSTRAINT `blotter_participants_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blotter_participants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blotter_participants_ibfk_3` FOREIGN KEY (`external_participant_id`) REFERENCES `external_participants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blotter_participants`
--
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('1', NULL, '1', '10', 'complainant', 'Neighbor is playing loud music past 10 PM');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('2', NULL, '2', '11', 'complainant', 'Neighbor built fence on my property');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('3', NULL, '3', '12', 'complainant', 'Need help resolving family issues');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('4', NULL, '4', '11', 'complainant', 'Neighbor destroyed my fence during argument');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('4', NULL, '5', '12', 'respondent', 'Accident occurred while trimming trees');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('1', '1', '6', NULL, 'respondent', 'We were just celebrating a birthday');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('5', NULL, '7', '28', 'complainant', 'Neighbor plays loud karaoke until midnight even on weekdays. We have small children who need to sleep early.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('5', NULL, '8', '29', 'respondent', 'We only sing during weekends and special occasions. The volume is not that loud.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('6', NULL, '9', '29', 'complainant', 'The new fence they built encroached 2 meters into my property. I have the old survey documents.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('6', NULL, '10', '32', 'respondent', 'We built the fence based on our property title. We are willing to have it re-surveyed.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('7', NULL, '11', '31', 'complainant', 'My husband has been physically abusing me for months. I fear for my safety and my children.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('7', NULL, '12', '32', 'witness', 'I heard screaming and saw bruises on her arms. This has happened multiple times.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('8', NULL, '13', '32', 'complainant', 'Several motorcycle parts worth 15,000 pesos were stolen from my shop. I suspect it was an inside job.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('9', NULL, '14', '38', 'complainant', 'My son rarely visits, doesn\'t provide food or medicine. I am left alone most days without proper care.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('9', NULL, '15', '41', 'respondent', 'I work two jobs to support my family. I send money for her needs but cannot visit daily.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('10', NULL, '16', '33', 'complainant', 'Construction work starts at 5 AM and continues past 8 PM. This violates barangay ordinance.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('10', NULL, '17', '45', 'respondent', 'We need to finish the project on time. We will adjust our working hours as requested.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('11', NULL, '18', '34', 'complainant', 'Neighbor parks his car blocking our gate. We cannot get our vehicle out during emergencies.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('11', NULL, '19', '36', 'respondent', 'There is limited parking space. I am willing to discuss alternative parking arrangements.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('12', NULL, '20', '35', 'complainant', 'My siblings are trying to sell our family home without proper division of inheritance.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('12', NULL, '21', '43', 'respondent', 'The house needs major repairs. Selling is the most practical solution for all of us.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('13', NULL, '22', '36', 'complainant', 'Neighbor punched me during an argument about his dog destroying my garden.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('13', NULL, '23', '47', 'respondent', 'He first threw stones at my dog. I only defended myself when he became aggressive.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('14', NULL, '24', '43', 'complainant', 'Neighbor\'s rooster crows at 4 AM every day. It wakes up the entire neighborhood.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('14', NULL, '25', '44', 'respondent', 'Roosters naturally crow in the morning. This is normal farm animal behavior.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('7', '3', '26', NULL, 'witness', 'I saw the husband hitting his wife in their yard. This is not the first time.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('8', '4', '27', NULL, 'witness', 'I saw suspicious individuals near the shop around midnight before the theft was discovered.');
INSERT INTO `blotter_participants` (`blotter_case_id`, `external_participant_id`, `id`, `person_id`, `role`, `statement`) VALUES('13', '5', '28', NULL, 'witness', 'I saw both men fighting. It started as an argument but became physical quickly.');

-- --------------------------------------------------------
-- Table structure for `case_categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `case_categories`;
CREATE TABLE `case_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `case_categories`
--
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '1', 'RA 9262 (VAWC) ‐ Physical');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '2', 'RA 9262 (VAWC) ‐ Sexual');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '3', 'RA 9262 (VAWC) ‐ Psychosocial');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '4', 'RA 9262 (VAWC) ‐ Economic');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '5', 'RA 7877 (Sexual Harassment)');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '6', 'RA 9208 (Anti‐trafficking)');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '7', 'Psychological');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '8', 'Other cases / Bullying Emotional');
INSERT INTO `case_categories` (`description`, `id`, `name`) VALUES(NULL, '9', 'Programs/Activities/Projects Implemented');

-- --------------------------------------------------------
-- Table structure for `case_hearings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `case_hearings`;
CREATE TABLE `case_hearings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `hearing_date` datetime NOT NULL,
  `hearing_type` enum('initial','mediation','conciliation','final') NOT NULL,
  `hearing_notes` text,
  `hearing_outcome` enum('scheduled','conducted','postponed','resolved','failed','cancelled') DEFAULT 'scheduled',
  `presided_by_user_id` int DEFAULT NULL,
  `next_hearing_date` datetime DEFAULT NULL,
  `hearing_number` int DEFAULT '1',
  `presiding_officer_name` varchar(100) DEFAULT NULL,
  `presiding_officer_position` varchar(100) DEFAULT NULL,
  `is_mediation_successful` tinyint(1) DEFAULT '0',
  `resolution_details` text,
  `created_by_user_id` int DEFAULT NULL,
  `schedule_proposal_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `blotter_case_id` (`blotter_case_id`),
  KEY `presided_by_user_id` (`presided_by_user_id`),
  KEY `fk_case_hearings_created_by` (`created_by_user_id`),
  KEY `fk_case_hearings_schedule_proposal` (`schedule_proposal_id`),
  CONSTRAINT `case_hearings_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `case_hearings_ibfk_2` FOREIGN KEY (`presided_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_case_hearings_created_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_case_hearings_schedule_proposal` FOREIGN KEY (`schedule_proposal_id`) REFERENCES `schedule_proposals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `case_hearings`
--
INSERT INTO `case_hearings` (`blotter_case_id`, `created_by_user_id`, `hearing_date`, `hearing_notes`, `hearing_number`, `hearing_outcome`, `hearing_type`, `id`, `is_mediation_successful`, `next_hearing_date`, `presided_by_user_id`, `presiding_officer_name`, `presiding_officer_position`, `resolution_details`, `schedule_proposal_id`) VALUES('10', NULL, '2024-02-15 14:00:00', 'Both parties agreed to construction time limits 7 AM to 6 PM weekdays, no work on Sundays', '1', 'resolved', 'mediation', '1', '0', NULL, '19', 'Benjamin Lopez Aguilar', 'Barangay Chairperson', NULL, NULL);
INSERT INTO `case_hearings` (`blotter_case_id`, `created_by_user_id`, `hearing_date`, `hearing_notes`, `hearing_number`, `hearing_outcome`, `hearing_type`, `id`, `is_mediation_successful`, `next_hearing_date`, `presided_by_user_id`, `presiding_officer_name`, `presiding_officer_position`, `resolution_details`, `schedule_proposal_id`) VALUES('5', NULL, '2024-02-20 14:00:00', 'Initial hearing to establish facts and attempt mediation', '1', 'scheduled', 'mediation', '2', '0', NULL, '9', 'Ricardo Morales', 'Chief Officer', NULL, NULL);
INSERT INTO `case_hearings` (`blotter_case_id`, `created_by_user_id`, `hearing_date`, `hearing_notes`, `hearing_number`, `hearing_outcome`, `hearing_type`, `id`, `is_mediation_successful`, `next_hearing_date`, `presided_by_user_id`, `presiding_officer_name`, `presiding_officer_position`, `resolution_details`, `schedule_proposal_id`) VALUES('7', NULL, '2024-02-22 10:00:00', 'VAWC case requires careful handling and counseling', '1', 'scheduled', 'initial', '3', '0', NULL, '9', 'Ricardo Morales', 'Chief Officer', NULL, NULL);
INSERT INTO `case_hearings` (`blotter_case_id`, `created_by_user_id`, `hearing_date`, `hearing_notes`, `hearing_number`, `hearing_outcome`, `hearing_type`, `id`, `is_mediation_successful`, `next_hearing_date`, `presided_by_user_id`, `presiding_officer_name`, `presiding_officer_position`, `resolution_details`, `schedule_proposal_id`) VALUES('11', NULL, '2024-02-21 15:00:00', 'Parking arrangement discussion between neighbors', '1', 'scheduled', 'conciliation', '4', '0', NULL, '19', 'Benjamin Lopez Aguilar', 'Barangay Chairperson', NULL, NULL);
INSERT INTO `case_hearings` (`blotter_case_id`, `created_by_user_id`, `hearing_date`, `hearing_notes`, `hearing_number`, `hearing_outcome`, `hearing_type`, `id`, `is_mediation_successful`, `next_hearing_date`, `presided_by_user_id`, `presiding_officer_name`, `presiding_officer_position`, `resolution_details`, `schedule_proposal_id`) VALUES('13', NULL, '2024-02-23 16:00:00', 'Assault case mediation with witness statements', '1', 'scheduled', 'mediation', '5', '0', NULL, '19', 'Benjamin Lopez Aguilar', 'Barangay Chairperson', NULL, NULL);

-- --------------------------------------------------------
-- Table structure for `case_interventions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `case_interventions`;
CREATE TABLE `case_interventions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `case_interventions`
--
INSERT INTO `case_interventions` (`description`, `id`, `name`) VALUES(NULL, '1', 'M/CSWD');
INSERT INTO `case_interventions` (`description`, `id`, `name`) VALUES(NULL, '2', 'PNP');
INSERT INTO `case_interventions` (`description`, `id`, `name`) VALUES(NULL, '3', 'Court');
INSERT INTO `case_interventions` (`description`, `id`, `name`) VALUES(NULL, '4', 'Issued BPO');
INSERT INTO `case_interventions` (`description`, `id`, `name`) VALUES(NULL, '5', 'Medical');

-- --------------------------------------------------------
-- Table structure for `case_notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `case_notifications`;
CREATE TABLE `case_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `notified_user_id` int NOT NULL,
  `notification_type` enum('case_filed','case_accepted','hearing_scheduled','signature_required','schedule_confirmation','schedule_approved','schedule_rejected') NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `blotter_case_id` (`blotter_case_id`),
  KEY `notified_user_id` (`notified_user_id`),
  CONSTRAINT `case_notifications_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `case_notifications_ibfk_2` FOREIGN KEY (`notified_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `cfa_certificates`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `cfa_certificates`;
CREATE TABLE `cfa_certificates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `complainant_person_id` int DEFAULT NULL,
  `issued_by_user_id` int DEFAULT NULL,
  `certificate_number` varchar(50) NOT NULL,
  `issued_at` datetime NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `blotter_case_id` (`blotter_case_id`),
  KEY `complainant_person_id` (`complainant_person_id`),
  KEY `issued_by_user_id` (`issued_by_user_id`),
  CONSTRAINT `cfa_certificates_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cfa_certificates_ibfk_2` FOREIGN KEY (`complainant_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cfa_certificates_ibfk_3` FOREIGN KEY (`issued_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cfa_certificates`
--
INSERT INTO `cfa_certificates` (`blotter_case_id`, `certificate_number`, `complainant_person_id`, `id`, `issued_at`, `issued_by_user_id`, `reason`) VALUES('1', 'TAM-CFA-2024-001', '10', '1', '2025-06-06 20:48:00', '4', 'Successful mediation between parties');

-- --------------------------------------------------------
-- Table structure for `child_disabilities`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `child_disabilities`;
CREATE TABLE `child_disabilities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `disability_type` enum('Blind/Visually Impaired','Hearing Impairment','Speech/Communication','Orthopedic/Physical','Intellectual/Learning','Psychosocial') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `child_disabilities_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `child_health_conditions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `child_health_conditions`;
CREATE TABLE `child_health_conditions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `condition_type` enum('Malaria','Dengue','Pneumonia','Tuberculosis','Diarrhea') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `child_health_conditions_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `child_information`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `child_information`;
CREATE TABLE `child_information` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `is_malnourished` tinyint(1) DEFAULT '0',
  `attending_school` tinyint(1) DEFAULT '0',
  `school_name` varchar(255) DEFAULT NULL,
  `grade_level` varchar(50) DEFAULT NULL,
  `school_type` enum('Public','Private','ALS','Day Care','SNP','Not Attending') DEFAULT 'Not Attending',
  `immunization_complete` tinyint(1) DEFAULT '0',
  `is_pantawid_beneficiary` tinyint(1) DEFAULT '0',
  `has_timbang_operation` tinyint(1) DEFAULT '0',
  `has_feeding_program` tinyint(1) DEFAULT '0',
  `has_supplementary_feeding` tinyint(1) DEFAULT '0',
  `in_caring_institution` tinyint(1) DEFAULT '0',
  `is_under_foster_care` tinyint(1) DEFAULT '0',
  `is_directly_entrusted` tinyint(1) DEFAULT '0',
  `is_legally_adopted` tinyint(1) DEFAULT '0',
  `occupation` varchar(255) DEFAULT NULL,
  `garantisadong_pambata` tinyint(1) DEFAULT '0',
  `under_six_years` tinyint(1) DEFAULT '0',
  `grade_school` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `child_information_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `custom_services`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `custom_services`;
CREATE TABLE `custom_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `barangay_id` int NOT NULL,
  `service_type` varchar(50) DEFAULT 'general',
  `name` varchar(100) NOT NULL,
  `description` text,
  `detailed_guide` text,
  `requirements` text,
  `processing_time` varchar(100) DEFAULT NULL,
  `fees` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fa-file',
  `url_path` varchar(255) DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `priority_level` enum('normal','high','urgent') DEFAULT 'normal',
  `availability_type` enum('always','scheduled','limited') DEFAULT 'always',
  `additional_notes` text,
  `is_archived` tinyint(1) DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `service_photo` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `custom_services_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `service_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_services_ibfk_2` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `custom_services`
--
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '32', '1', 'Submit document requests online with digital delivery option', 'Fill out online form, upload requirements, choose delivery method', '1', 'Varies by document type', 'fa-laptop', '1', '1', '0', 'Online Document Request', 'high', '1-3 business days', 'Valid ID, supporting documents', NULL, 'digital', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '32', '2', 'Health services brought directly to your purok', 'Schedule appointment through barangay health worker', '1', 'Free for basic services', 'fa-ambulance', '2', '1', '0', 'Mobile Health Clinic', 'high', 'By appointment', 'Valid ID, health records if available', NULL, 'mobile', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '32', '3', 'Professional mediation services for neighbor disputes', 'File complaint, attend scheduled hearing, reach agreement', '1', 'Free', 'fa-handshake', '3', '1', '0', 'Conflict Mediation', 'normal', '5-10 business days', 'Incident report, witness statements', NULL, 'legal', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '32', '4', 'Free internet access for students and workers', 'Register at barangay hall, bring valid student/work ID', '1', 'Free', 'fa-wifi', '4', '1', '0', 'Community Wi-Fi Access', 'normal', 'Same day', 'Valid ID, proof of residence', NULL, 'digital', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '32', '5', 'Free consultation for starting small businesses', 'Schedule appointment with business development officer', '1', 'Free', 'fa-lightbulb', '5', '1', '0', 'Business Consultation', 'normal', '1 week', 'Business plan draft, valid ID', NULL, 'consultation', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '3', '6', 'Technical assistance for farmers and gardeners', 'Contact agricultural officer, schedule field visit', '1', 'Free', 'fa-seedling', '6', '1', '0', 'Agricultural Extension', 'high', '3-5 business days', 'Farm/garden location details', NULL, 'agricultural', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '3', '7', 'Assistance program for elderly residents', 'Register at barangay office, submit requirements', '1', 'Free', 'fa-user-plus', '7', '1', '0', 'Senior Citizen Support', 'high', '5 business days', 'OSCA ID, medical certificate if needed', NULL, 'social', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '3', '8', 'File complaints and legal cases online', 'Submit complaint form, upload evidence', '1', 'Free', 'fa-clipboard-list', '8', '1', '0', 'Blotter Case Filing', 'urgent', '1-2 business days', 'Incident details, witness information', NULL, 'legal', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '3', '9', 'Skills development and livelihood programs', 'Apply for training slots, attend orientation', '1', 'Free with materials fee', 'fa-tools', '9', '1', '0', 'Livelihood Training', 'normal', '2-4 weeks', 'Valid ID, commitment letter', NULL, 'educational', NULL);
INSERT INTO `custom_services` (`additional_notes`, `archived_at`, `availability_type`, `barangay_id`, `category_id`, `description`, `detailed_guide`, `display_order`, `fees`, `icon`, `id`, `is_active`, `is_archived`, `name`, `priority_level`, `processing_time`, `requirements`, `service_photo`, `service_type`, `url_path`) VALUES(NULL, NULL, 'always', '3', '10', '24/7 emergency assistance and coordination', 'Call emergency hotline or visit barangay hall', '1', 'Free', 'fa-exclamation-triangle', '10', '1', '0', 'Emergency Response', 'urgent', 'Immediate', 'Emergency nature, contact information', NULL, 'emergency', NULL);

-- --------------------------------------------------------
-- Table structure for `document_attribute_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `document_attribute_types`;
CREATE TABLE `document_attribute_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(40) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_doc_attr_code` (`document_type_id`,`code`),
  CONSTRAINT `document_attribute_types_ibfk_1` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `document_attribute_types`
--
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('clearance_purpose', 'Purpose for barangay clearance', '1', '1', '1', 'Purpose for Clearance');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('residency_duration', 'How long the requester has resided', '3', '2', '1', 'Duration of Residency');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('residency_purpose', 'Purpose for certificate of residency', '3', '3', '1', 'Purpose for Certificate');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('indigency_purpose', 'Purpose for indigency certificate', '4', '4', '1', 'Purpose for Certificate');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('indigency_income', 'Stated income for indigency cert.', '4', '5', '1', 'Stated Income');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('indigency_reason', 'Reason for requesting indigency cert.', '4', '6', '1', 'Reason for Request');
INSERT INTO `document_attribute_types` (`code`, `description`, `document_type_id`, `id`, `is_required`, `name`) VALUES('cedula_amount', 'Tax amount for cedula', '5', '7', '1', 'Tax Amount');

-- --------------------------------------------------------
-- Table structure for `document_request_attributes`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `document_request_attributes`;
CREATE TABLE `document_request_attributes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `attribute_type_id` int NOT NULL,
  `value` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_request_attribute` (`request_id`,`attribute_type_id`),
  KEY `attribute_type_id` (`attribute_type_id`),
  CONSTRAINT `document_request_attributes_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `document_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_request_attributes_ibfk_2` FOREIGN KEY (`attribute_type_id`) REFERENCES `document_attribute_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `document_request_restrictions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `document_request_restrictions`;
CREATE TABLE `document_request_restrictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `document_type_code` varchar(50) NOT NULL,
  `first_requested_at` datetime NOT NULL,
  `request_count` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_document_restriction` (`person_id`,`document_type_code`),
  KEY `idx_document_restrictions` (`document_type_code`,`person_id`),
  CONSTRAINT `document_request_restrictions_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `document_requests`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `document_requests`;
CREATE TABLE `document_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `document_type_id` int NOT NULL,
  `barangay_id` int NOT NULL,
  `status` enum('pending','completed','rejected','processing','for_payment','archived') DEFAULT 'pending',
  `price` decimal(10,2) DEFAULT '0.00',
  `remarks` text,
  `proof_image_path` varchar(255) DEFAULT NULL,
  `requested_by_user_id` int DEFAULT NULL,
  `processed_by_user_id` int DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `request_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `purpose` text,
  `ctc_number` varchar(100) DEFAULT NULL,
  `or_number` varchar(100) DEFAULT NULL,
  `business_name` varchar(100) DEFAULT NULL,
  `business_location` varchar(200) DEFAULT NULL,
  `business_nature` varchar(200) DEFAULT NULL,
  `business_type` varchar(100) DEFAULT NULL,
  `delivery_method` set('hardcopy','softcopy') DEFAULT 'hardcopy',
  `payment_method` enum('cash','online') DEFAULT 'cash',
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `payment_reference` varchar(100) DEFAULT NULL,
  `paymongo_checkout_id` varchar(100) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `barangay_id` (`barangay_id`),
  KEY `requested_by_user_id` (`requested_by_user_id`),
  KEY `processed_by_user_id` (`processed_by_user_id`),
  KEY `idx_doc_requests_status_barangay` (`status`,`barangay_id`,`request_date`),
  KEY `idx_doc_requests_person` (`person_id`),
  KEY `idx_doc_requests_doctype` (`document_type_id`),
  KEY `idx_doc_requests_user` (`user_id`),
  CONSTRAINT `document_requests_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `document_requests_ibfk_3` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_requests_ibfk_4` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_requests_ibfk_5` FOREIGN KEY (`requested_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `document_requests_ibfk_6` FOREIGN KEY (`processed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `document_requests`
--
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '1', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '10', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '3', '2', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '11', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '4', '3', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '12', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '4', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '13', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '3', '5', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '14', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '5', '6', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '5', '0.00', NULL, NULL, NULL, NULL, '3', 'pending', '5');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '7', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '28', '50.00', NULL, NULL, 'Job application requirements', NULL, '11', 'completed', '21');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '3', '8', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '29', '30.00', NULL, NULL, 'Bank account opening', NULL, '11', 'pending', '22');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '4', '9', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '30', '0.00', NULL, NULL, 'Medical assistance application', NULL, '11', 'completed', '23');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'softcopy', '2', '10', '0', NULL, NULL, 'online', NULL, 'paid', NULL, '31', '0.00', NULL, NULL, 'First job application', NULL, '11', 'completed', '24');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '6', '11', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '32', '100.00', NULL, NULL, 'Auto repair shop permit', NULL, '11', 'processing', '25');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '12', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '38', '50.00', NULL, NULL, 'Senior citizen ID application', NULL, '11', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('32', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '3', '13', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '42', '30.00', NULL, NULL, 'Employment verification', NULL, '11', 'completed', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '14', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '33', '50.00', NULL, NULL, 'Loan application requirement', NULL, '16', 'completed', '26');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'softcopy', '3', '15', '0', NULL, NULL, 'online', NULL, 'pending', NULL, '34', '30.00', NULL, NULL, 'Professional license renewal', NULL, '16', 'pending', '27');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '4', '16', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '35', '0.00', NULL, NULL, 'Social services application', NULL, '16', 'completed', '28');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '17', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '36', '50.00', NULL, NULL, 'Jeepney franchise renewal', NULL, '16', 'processing', '29');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '4', '18', '0', NULL, NULL, 'cash', NULL, 'paid', NULL, '37', '0.00', NULL, NULL, 'Widow pension application', NULL, '16', 'completed', '30');
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '1', '19', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '43', '50.00', NULL, NULL, 'Jeepney driver license', NULL, '16', 'pending', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'hardcopy', '6', '20', '0', NULL, NULL, 'cash', NULL, 'pending', NULL, '45', '100.00', NULL, NULL, 'Electrical contractor permit', NULL, '16', 'processing', NULL);
INSERT INTO `document_requests` (`barangay_id`, `business_location`, `business_name`, `business_nature`, `business_type`, `completed_at`, `ctc_number`, `delivery_method`, `document_type_id`, `id`, `is_archived`, `or_number`, `payment_date`, `payment_method`, `payment_reference`, `payment_status`, `paymongo_checkout_id`, `person_id`, `price`, `processed_by_user_id`, `proof_image_path`, `purpose`, `remarks`, `requested_by_user_id`, `status`, `user_id`) VALUES('3', NULL, NULL, NULL, NULL, NULL, NULL, 'softcopy', '3', '21', '0', NULL, NULL, 'online', NULL, 'paid', NULL, '46', '30.00', NULL, NULL, 'Bank employment verification', NULL, '16', 'completed', NULL);

-- --------------------------------------------------------
-- Table structure for `document_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `document_types`;
CREATE TABLE `document_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text,
  `default_fee` decimal(10,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `document_types`
--
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('barangay_clearance', '50.00', 'A clearance issued by the Barangay.', '1', '1', 'Barangay Clearance');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('first_time_job_seeker', '0.00', 'Certification for first‐time job seekers.', '2', '1', 'First Time Job Seeker');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('proof_of_residency', '30.00', 'Official proof of residency certificate.', '3', '1', 'Proof of Residency');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('barangay_indigency', '0.00', 'A document certifying indigency status.', '4', '1', 'Barangay Indigency');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('cedula', '30.00', 'Community Tax Certificate (Cedula)', '5', '1', 'Cedula');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('business_permit_clearance', '100.00', 'Barangay clearance for business permit.', '6', '1', 'Business Permit Clearance');
INSERT INTO `document_types` (`code`, `default_fee`, `description`, `id`, `is_active`, `name`) VALUES('no_income_certification', '0.00', 'Certification for individuals with no regular income.', '7', '1', 'No Income Certification');

-- --------------------------------------------------------
-- Table structure for `email_logs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `to_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_used` varchar(100) DEFAULT NULL,
  `sent_at` datetime NOT NULL,
  `status` enum('sent','failed','pending') DEFAULT 'pending',
  `error_message` text,
  `blotter_case_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `blotter_case_id` (`blotter_case_id`),
  CONSTRAINT `email_logs_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `emergency_contacts`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `emergency_contacts`;
CREATE TABLE `emergency_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `contact_address` varchar(200) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `emergency_contacts_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `emergency_contacts`
--
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('202 Rizal Street, Tambubong', 'Maria Reyes Garcia', '09182345678', '1', '28', 'Spouse');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('101 Mabini Extension, Tambubong', 'Juan Cruz Santos', '09171234567', '2', '29', 'Spouse');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('78 Santos Street, Tambubong', 'Ana Garcia Reyes', '09204567890', '3', '30', 'Daughter');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('92 Mendoza Avenue, Tambubong', 'Carlos Torres Mendoza', '09215678901', '4', '31', 'Brother');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('133 Health Worker Lane, Tambubong', 'Gloria Mendoza Reyes', '09305678901', '5', '32', 'Spouse');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('77 Driver Avenue, Caingin', 'Fernando Santos Lopez', '09306789012', '6', '33', 'Spouse');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('67 Engineers Village, Caingin', 'Carlos Eduardo Torres', '09308901234', '7', '34', 'Son');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('456 Maligaya Street, Caingin', 'Luis Santos Martinez', '09226789012', '8', '35', 'Son');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('134 Medical Center Road, Caingin', 'Elena Martinez Cruz', '09260123456', '9', '36', 'Sister');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('177 Fisherman Lane, Caingin', 'Domingo Torres Delgado', '09310123456', '10', '37', 'Spouse');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('111 Construction Road, Tambubong', 'Roberto Cruz Villanueva', '09304567890', '11', '38', 'Son');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('456 Maligaya Street, Caingin', 'Rosa Santos Martinez', '09226789012', '12', '43', 'Daughter');
INSERT INTO `emergency_contacts` (`contact_address`, `contact_name`, `contact_number`, `id`, `person_id`, `relationship`) VALUES('122 Electrician Road, Caingin', 'Antonio Reyes Torres', '09308901234', '13', '44', 'Spouse');

-- --------------------------------------------------------
-- Table structure for `event_participants`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `event_participants`;
CREATE TABLE `event_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `person_id` int NOT NULL,
  `attendance_status` enum('registered','confirmed','attended','no_show') DEFAULT 'registered',
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_person` (`event_id`,`person_id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `event_participants_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_participants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `event_participants`
--
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '1', '1', '5', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '1', '2', '10', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '1', '3', '11', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '1', '4', '12', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '2', '5', '5', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '2', '6', '10', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '2', '7', '11', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '5', '8', '28', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '5', '9', '29', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '5', '10', '30', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '5', '11', '31', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '5', '12', '32', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '5', '13', '38', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '5', '14', '39', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '5', '15', '41', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '6', '16', '30', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '6', '17', '38', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '6', '18', '39', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '6', '19', '40', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '8', '20', '48', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '8', '21', '49', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '8', '22', '50', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '8', '23', '51', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '10', '24', '33', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '10', '25', '36', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '10', '26', '43', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '10', '27', '47', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '11', '28', '35', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '11', '29', '44', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '11', '30', '52', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '11', '31', '53', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '11', '32', '55', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '12', '33', '33', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '12', '34', '35', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '12', '35', '37', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('confirmed', '12', '36', '44', NULL);
INSERT INTO `event_participants` (`attendance_status`, `event_id`, `id`, `person_id`, `remarks`) VALUES('registered', '12', '37', '46', NULL);

-- --------------------------------------------------------
-- Table structure for `events`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `location` varchar(200) NOT NULL,
  `organizer` varchar(100) DEFAULT NULL,
  `barangay_id` int NOT NULL,
  `created_by_user_id` int NOT NULL,
  `status` enum('scheduled','ongoing','completed','postponed','cancelled') DEFAULT 'scheduled',
  `max_participants` int DEFAULT NULL,
  `registration_required` tinyint(1) DEFAULT '0',
  `registration_deadline` datetime DEFAULT NULL,
  `event_type` enum('meeting','seminar','activity','celebration','emergency','other') DEFAULT 'other',
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `requirements` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `target_roles` text,
  PRIMARY KEY (`id`),
  KEY `barangay_id` (`barangay_id`),
  KEY `created_by_user_id` (`created_by_user_id`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `events_ibfk_2` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `events`
--
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', NULL, NULL, '3', 'Monthly community cleanup', '2024-03-05 11:00:00', 'other', '1', 'Tambubong Covered Court', NULL, NULL, NULL, NULL, '0', NULL, '2024-03-05 07:00:00', 'scheduled', NULL, 'Tambubong Cleanup Day');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', NULL, NULL, '3', 'Monthly barangay assembly meeting', '2024-02-15 21:00:00', 'other', '2', 'Barangay Hall', NULL, NULL, NULL, NULL, '0', NULL, '2024-02-15 19:00:00', 'scheduled', NULL, 'Barangay Assembly');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('18', NULL, NULL, '3', 'Free medical checkup and consultation', '2024-02-20 17:00:00', 'other', '3', 'Covered Court', NULL, NULL, NULL, NULL, '0', NULL, '2024-02-20 08:00:00', 'scheduled', NULL, 'Health Fair');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', NULL, NULL, '3', 'Community clean-up activity', '2024-02-25 10:00:00', 'other', '4', 'Various Streets', NULL, NULL, NULL, NULL, '0', NULL, '2024-02-25 06:00:00', 'scheduled', NULL, 'Clean-up Drive');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', '09171234501', 'Maria Rodriguez', '11', 'Community-wide cleanup and beautification activity', '2024-03-02 10:00:00', 'activity', '5', 'Various streets in Tambubong', '100', NULL, 'Barangay Council', NULL, '1', 'Bring own cleaning materials, wear comfortable clothes', '2024-03-02 06:00:00', 'scheduled', NULL, 'Tambubong Monthly Cleanup Drive');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', '09171234505', 'Dr. Elena Cruz', '15', 'Free medical checkup and consultation for senior citizens', '2024-03-05 16:00:00', 'seminar', '6', 'Tambubong Covered Court', '50', NULL, 'Barangay Health Center', NULL, '1', 'Bring valid ID and health records', '2024-03-05 08:00:00', 'scheduled', NULL, 'Senior Citizens Health Fair');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', '09171234500', 'Juan Dela Cruz', '4', 'Monthly barangay assembly and community updates', '2024-03-10 21:00:00', 'meeting', '7', 'Tambubong Barangay Hall', '200', NULL, 'Barangay Council', NULL, '0', 'Open to all residents', '2024-03-10 19:00:00', 'scheduled', NULL, 'Barangay Assembly Meeting');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', '09171234503', 'Carmen Villanueva', '13', 'Livelihood skills training for out-of-school youth', '2024-03-17 16:00:00', 'seminar', '8', 'Tambubong Multi-Purpose Center', '30', NULL, 'TESDA-Barangay Partnership', NULL, '1', 'Ages 16-25, bring birth certificate', '2024-03-15 09:00:00', 'scheduled', NULL, 'Youth Skills Training Program');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('32', '09171234504', 'Roberto Fernandez', '14', 'Earthquake and fire safety drill for the community', '2024-03-20 17:00:00', 'activity', '9', 'Tambubong Elementary School', '300', NULL, 'Barangay Disaster Risk Reduction Team', NULL, '0', 'Participation encouraged for all ages', '2024-03-20 14:00:00', 'scheduled', NULL, 'Disaster Preparedness Drill');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', '09171234506', 'Luz Mercado', '16', 'Monthly local farmers and vendors market', '2024-03-03 12:00:00', 'activity', '10', 'Caingin Basketball Court', '80', NULL, 'Farmers Association', NULL, '1', 'Local farmers and vendors only', '2024-03-03 05:00:00', 'scheduled', NULL, 'Caingin Farmers Market');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', '09171234510', 'Rosa Delgado', '20', 'Free feeding for children and senior citizens', '2024-03-07 13:00:00', 'activity', '11', 'Caingin Day Care Center', '100', NULL, 'Barangay Nutrition Committee', NULL, '0', 'Children 5 years old and below, senior citizens', '2024-03-07 11:00:00', 'scheduled', NULL, 'Community Feeding Program');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', '09171234508', 'Alma Torres', '18', 'Sewing and handicraft skills training for women', '2024-03-14 17:00:00', 'seminar', '12', 'Caingin Women\'s Center', '25', NULL, 'Women\'s Organization', NULL, '1', 'Women 18 years old and above', '2024-03-12 13:00:00', 'scheduled', NULL, 'Livelihood Training for Women');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', '09171234509', 'Roberto Reyes', '8', 'Planning meeting for annual barangay fiesta', '2024-03-18 20:00:00', 'meeting', '13', 'Caingin Barangay Hall', '50', NULL, 'Fiesta Committee', NULL, '0', 'Committee members and volunteers', '2024-03-18 18:00:00', 'scheduled', NULL, 'Barangay Fiesta Preparation Meeting');
INSERT INTO `events` (`barangay_id`, `contact_number`, `contact_person`, `created_by_user_id`, `description`, `end_datetime`, `event_type`, `id`, `location`, `max_participants`, `notes`, `organizer`, `registration_deadline`, `registration_required`, `requirements`, `start_datetime`, `status`, `target_roles`, `title`) VALUES('3', '09171234507', 'Jose Ramirez', '17', 'Proper waste segregation and environmental protection', '2024-03-25 17:00:00', 'seminar', '14', 'Caingin Covered Court', '150', NULL, 'Environmental Committee', NULL, '0', 'Open to all residents', '2024-03-25 14:00:00', 'scheduled', NULL, 'Environmental Awareness Seminar');

-- --------------------------------------------------------
-- Table structure for `external_participants`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `external_participants`;
CREATE TABLE `external_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` enum('Male','Female','Others') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `external_participants`
--
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Unknown Street, Tambubong', '35', '09888777666', 'Carlos', 'Male', '1', 'Rivera');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Somewhere in Pantubig', '28', '09555444333', 'Elena', 'Female', '2', 'Cruz');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Unknown address, Neighboring barangay', '32', '09888111222', 'Mark', 'Male', '3', 'Gonzales');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Pantubig, San Rafael', '28', '09777333444', 'Susan', 'Female', '4', 'Bautista');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Diliman, San Rafael', '35', '09666555777', 'David', 'Male', '5', 'Ramos');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Libis, San Rafael', '26', '09555888999', 'Jenny', 'Female', '6', 'Morales');
INSERT INTO `external_participants` (`address`, `age`, `contact_number`, `first_name`, `gender`, `id`, `last_name`) VALUES('Unknown address, San Rafael', '45', '09444222333', 'Robert', 'Male', '7', 'Silva');

-- --------------------------------------------------------
-- Table structure for `family_composition`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `family_composition`;
CREATE TABLE `family_composition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `person_id` int NOT NULL,
  `name` varchar(150) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `age` int NOT NULL,
  `civil_status` enum('SINGLE','MARRIED','WIDOW/WIDOWER','SEPARATED') NOT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `monthly_income` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `household_id` (`household_id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `family_composition_ibfk_1` FOREIGN KEY (`household_id`) REFERENCES `households` (`id`) ON DELETE CASCADE,
  CONSTRAINT `family_composition_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `government_programs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `government_programs`;
CREATE TABLE `government_programs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `nhts_pr_listahanan` tinyint(1) DEFAULT '0',
  `indigenous_people` tinyint(1) DEFAULT '0',
  `pantawid_beneficiary` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `government_programs_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `hearing_attendances`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `hearing_attendances`;
CREATE TABLE `hearing_attendances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hearing_id` int NOT NULL,
  `participant_id` int NOT NULL,
  `is_present` tinyint(1) DEFAULT '0',
  `remarks` varchar(255) DEFAULT NULL,
  `participant_type` varchar(20) DEFAULT NULL,
  `attendance_remarks` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_hearing_participant` (`hearing_id`,`participant_id`),
  KEY `participant_id` (`participant_id`),
  CONSTRAINT `hearing_attendances_ibfk_1` FOREIGN KEY (`hearing_id`) REFERENCES `case_hearings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `hearing_attendances_ibfk_2` FOREIGN KEY (`participant_id`) REFERENCES `blotter_participants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `hearing_schedules`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `hearing_schedules`;
CREATE TABLE `hearing_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hearing_date` date NOT NULL,
  `hearing_time` time NOT NULL,
  `location` varchar(255) DEFAULT 'Barangay Hall',
  `max_hearings_per_slot` int DEFAULT '5',
  `current_bookings` int DEFAULT '0',
  `is_available` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `household_members`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `household_members`;
CREATE TABLE `household_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `household_id` int NOT NULL,
  `person_id` int NOT NULL,
  `relationship_type_id` int NOT NULL,
  `is_household_head` tinyint(1) DEFAULT '0',
  `relationship_to_head` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_household_person` (`household_id`,`person_id`),
  KEY `person_id` (`person_id`),
  KEY `relationship_type_id` (`relationship_type_id`),
  CONSTRAINT `household_members_ibfk_1` FOREIGN KEY (`household_id`) REFERENCES `households` (`id`) ON DELETE CASCADE,
  CONSTRAINT `household_members_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `household_members_ibfk_3` FOREIGN KEY (`relationship_type_id`) REFERENCES `relationship_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `household_members`
--
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('1', '1', '1', '21', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('1', '2', '0', '22', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('1', '3', '0', '41', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('1', '4', '0', '42', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('2', '5', '1', '22', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('2', '6', '0', '43', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('2', '7', '0', '44', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('3', '8', '1', '23', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('3', '9', '0', '33', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('4', '10', '1', '24', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('5', '11', '1', '25', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('5', '12', '0', '35', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('5', '13', '0', '32', 'PARENT', '4');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('11', '14', '1', '26', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('11', '15', '0', '45', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('11', '16', '0', '46', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('11', '17', '0', '36', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('12', '18', '1', '27', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('12', '19', '0', '47', 'CHILD', '3');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('12', '20', '0', '38', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('13', '21', '1', '28', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('14', '22', '1', '29', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('15', '23', '1', '30', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('20', '24', '1', '40', 'HEAD', '1');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('20', '25', '0', '37', 'SPOUSE', '2');
INSERT INTO `household_members` (`household_id`, `id`, `is_household_head`, `person_id`, `relationship_to_head`, `relationship_type_id`) VALUES('20', '26', '0', '48', 'CHILD', '3');

-- --------------------------------------------------------
-- Table structure for `households`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `households`;
CREATE TABLE `households` (
  `id` int NOT NULL AUTO_INCREMENT,
  `household_number` varchar(50) NOT NULL,
  `barangay_id` int NOT NULL,
  `purok_id` int DEFAULT NULL,
  `household_head_person_id` int DEFAULT NULL,
  `household_size` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_household_number` (`household_number`,`barangay_id`,`purok_id`),
  KEY `barangay_id` (`barangay_id`),
  KEY `purok_id` (`purok_id`),
  KEY `household_head_person_id` (`household_head_person_id`),
  CONSTRAINT `households_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `households_ibfk_2` FOREIGN KEY (`purok_id`) REFERENCES `purok` (`id`) ON DELETE SET NULL,
  CONSTRAINT `households_ibfk_3` FOREIGN KEY (`household_head_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `households`
--
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '21', 'TAM-2024-001', '4', '1', '1');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '22', 'TAM-2024-002', '3', '2', '1');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '23', 'TAM-2024-003', '2', '3', '2');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '24', 'TAM-2024-004', '1', '4', '2');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '25', 'TAM-2024-005', '5', '5', '3');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '31', 'TAM-2024-006', '1', '6', '3');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '32', 'TAM-2024-007', '3', '7', '4');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '33', 'TAM-2024-008', '2', '8', '4');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '34', 'TAM-2024-009', '1', '9', '5');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('32', '35', 'TAM-2024-010', '4', '10', '5');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '26', 'CAI-2024-001', '4', '11', '6');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '27', 'CAI-2024-002', '3', '12', '6');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '28', 'CAI-2024-003', '1', '13', '7');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '29', 'CAI-2024-004', '1', '14', '7');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '30', 'CAI-2024-005', '1', '15', '8');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '36', 'CAI-2024-006', '3', '16', '8');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '37', 'CAI-2024-007', '2', '17', '9');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '38', 'CAI-2024-008', '4', '18', '9');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '39', 'CAI-2024-009', '1', '19', '9');
INSERT INTO `households` (`barangay_id`, `household_head_person_id`, `household_number`, `household_size`, `id`, `purok_id`) VALUES('3', '40', 'CAI-2024-010', '5', '20', '9');

-- --------------------------------------------------------
-- Table structure for `income_source_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `income_source_types`;
CREATE TABLE `income_source_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `requires_amount` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `income_source_types`
--
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '1', 'Own Earnings/Salaries/Wages', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '2', 'Own Pension', '1');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '3', 'Stocks/Dividends', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '4', 'Dependent on Children/Relatives', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '5', 'Spouse Salary', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '6', 'Insurances', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '7', 'Spouse Pension', '1');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '8', 'Rentals/Sharecrops', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '9', 'Savings', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '10', 'Livestock/Orchards', '0');
INSERT INTO `income_source_types` (`description`, `id`, `name`, `requires_amount`) VALUES(NULL, '11', 'Others', '1');

-- --------------------------------------------------------
-- Table structure for `income_sources`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `income_sources`;
CREATE TABLE `income_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `own_earnings` tinyint(1) DEFAULT '0',
  `own_pension` tinyint(1) DEFAULT '0',
  `own_pension_amount` decimal(10,2) DEFAULT NULL,
  `stocks_dividends` tinyint(1) DEFAULT '0',
  `dependent_on_children` tinyint(1) DEFAULT '0',
  `spouse_salary` tinyint(1) DEFAULT '0',
  `insurances` tinyint(1) DEFAULT '0',
  `spouse_pension` tinyint(1) DEFAULT '0',
  `spouse_pension_amount` decimal(10,2) DEFAULT NULL,
  `rentals_sharecrops` tinyint(1) DEFAULT '0',
  `savings` tinyint(1) DEFAULT '0',
  `livestock_orchards` tinyint(1) DEFAULT '0',
  `others` tinyint(1) DEFAULT '0',
  `others_specify` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `income_sources_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `involvement_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `involvement_types`;
CREATE TABLE `involvement_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `involvement_types`
--
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '1', 'Medical');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '2', 'Resource Volunteer');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '3', 'Community Beautification');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '4', 'Community/Organizational Leader');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '5', 'Dental');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '6', 'Friendly Visits');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '7', 'Neighborhood Support Services');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '8', 'Religious');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '9', 'Counselling/Referral');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '10', 'Sponsorship');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '11', 'Legal Services');
INSERT INTO `involvement_types` (`description`, `id`, `name`) VALUES(NULL, '12', 'Others');

-- --------------------------------------------------------
-- Table structure for `living_arrangement_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `living_arrangement_types`;
CREATE TABLE `living_arrangement_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `living_arrangement_types`
--
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '1', 'Alone');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '2', 'Spouse');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '3', 'Care Institutions');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '4', 'Children');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '5', 'Grandchildren');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '6', 'Common Law Spouse');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '7', 'In laws');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '8', 'Relatives');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '9', 'Househelp');
INSERT INTO `living_arrangement_types` (`description`, `id`, `name`) VALUES(NULL, '10', 'Others');

-- --------------------------------------------------------
-- Table structure for `living_arrangements`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `living_arrangements`;
CREATE TABLE `living_arrangements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `spouse` tinyint(1) DEFAULT '0',
  `care_institutions` tinyint(1) DEFAULT '0',
  `children` tinyint(1) DEFAULT '0',
  `grandchildren` tinyint(1) DEFAULT '0',
  `househelps` tinyint(1) DEFAULT '0',
  `relatives` tinyint(1) DEFAULT '0',
  `others` tinyint(1) DEFAULT '0',
  `others_specify` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `living_arrangements_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `monthly_report_details`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `monthly_report_details`;
CREATE TABLE `monthly_report_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monthly_report_id` int NOT NULL,
  `category_id` int NOT NULL,
  `total_cases` int DEFAULT '0',
  `total_pnp` int DEFAULT '0',
  `total_court` int DEFAULT '0',
  `total_issued_bpo` int DEFAULT '0',
  `total_medical` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_report_category` (`monthly_report_id`,`category_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `monthly_report_details_ibfk_1` FOREIGN KEY (`monthly_report_id`) REFERENCES `monthly_reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `monthly_report_details_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `case_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `monthly_report_details`
--
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('1', '1', '1', '1', '0', '0', '1', '0');
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('8', '2', '1', '6', '0', '0', '0', '1');
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('8', '3', '2', '4', '0', '0', '0', '0');
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('1', '4', '3', '1', '0', '1', '1', '0');
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('8', '5', '3', '3', '0', '0', '0', '0');
INSERT INTO `monthly_report_details` (`category_id`, `id`, `monthly_report_id`, `total_cases`, `total_court`, `total_issued_bpo`, `total_medical`, `total_pnp`) VALUES('8', '6', '4', '2', '0', '0', '0', '0');

-- --------------------------------------------------------
-- Table structure for `monthly_reports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `monthly_reports`;
CREATE TABLE `monthly_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `report_month` int NOT NULL,
  `report_year` int NOT NULL,
  `created_by_user_id` int NOT NULL,
  `prepared_by_user_id` int DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barangay_month_year` (`barangay_id`,`report_month`,`report_year`),
  KEY `created_by_user_id` (`created_by_user_id`),
  KEY `prepared_by_user_id` (`prepared_by_user_id`),
  CONSTRAINT `monthly_reports_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `monthly_reports_ibfk_2` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `monthly_reports_ibfk_3` FOREIGN KEY (`prepared_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `monthly_reports`
--
INSERT INTO `monthly_reports` (`barangay_id`, `created_by_user_id`, `id`, `prepared_by_user_id`, `report_month`, `report_year`, `submitted_at`) VALUES('32', '4', '1', '9', '1', '2024', '2024-02-05 16:30:00');
INSERT INTO `monthly_reports` (`barangay_id`, `created_by_user_id`, `id`, `prepared_by_user_id`, `report_month`, `report_year`, `submitted_at`) VALUES('3', '8', '2', '19', '1', '2024', '2024-02-03 14:45:00');
INSERT INTO `monthly_reports` (`barangay_id`, `created_by_user_id`, `id`, `prepared_by_user_id`, `report_month`, `report_year`, `submitted_at`) VALUES('32', '4', '3', '9', '2', '2024', NULL);
INSERT INTO `monthly_reports` (`barangay_id`, `created_by_user_id`, `id`, `prepared_by_user_id`, `report_month`, `report_year`, `submitted_at`) VALUES('3', '8', '4', '19', '2', '2024', NULL);

-- --------------------------------------------------------
-- Table structure for `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'general',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `related_table` varchar(100) DEFAULT NULL,
  `related_id` int DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notifications`
--
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '1', '0', 'Your barangay clearance request has been approved and is ready for pickup.', 'medium', NULL, '7', 'document_requests', 'Document Request Approved', 'document_request', '21');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '2', '1', 'Your proof of residency request is being processed.', 'low', NULL, '8', 'document_requests', 'Document Request Processing', 'document_request', '22');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '3', '0', 'Your first time job seeker certificate is ready for download.', 'medium', NULL, '10', 'document_requests', 'Document Request Completed', 'document_request', '24');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '4', '0', 'A hearing for your noise complaint case has been scheduled for February 20, 2024.', 'high', NULL, '5', 'blotter_cases', 'Hearing Scheduled', 'blotter_case', '21');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '5', '1', 'Your domestic violence case has been filed and assigned for investigation.', 'urgent', NULL, '7', 'blotter_cases', 'Case Filed', 'blotter_case', '24');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '6', '0', 'Your noise disturbance case has been resolved through mediation.', 'medium', NULL, '10', 'blotter_cases', 'Case Resolved', 'blotter_case', '26');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '7', '1', 'You are registered for the Tambubong Monthly Cleanup Drive on March 2, 2024.', 'low', NULL, '5', 'events', 'Event Registration Confirmed', 'event', '21');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '8', '0', 'Senior Citizens Health Fair is tomorrow. Don\'t forget to bring your health records.', 'medium', NULL, '6', 'events', 'Health Fair Reminder', 'event', '23');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '9', '0', 'You have been accepted for the Livelihood Training for Women program.', 'high', NULL, '12', 'events', 'Training Confirmation', 'event', '26');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '10', '1', 'Monthly blotter case report for January 2024 is due for submission.', 'high', NULL, NULL, 'monthly_reports', 'Monthly Report Due', 'system', '4');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '11', '0', 'New assault case has been assigned to you for investigation.', 'urgent', NULL, '13', 'blotter_cases', 'Case Assignment', 'system', '8');
INSERT INTO `notifications` (`action_url`, `expires_at`, `id`, `is_read`, `message`, `priority`, `read_at`, `related_id`, `related_table`, `title`, `type`, `user_id`) VALUES(NULL, NULL, '12', '0', '5 new document requests received today requiring your review.', 'medium', NULL, NULL, 'document_requests', 'Bulk Processing', 'document_request', '11');

-- --------------------------------------------------------
-- Table structure for `other_need_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `other_need_types`;
CREATE TABLE `other_need_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` enum('social','economic','environmental','others') NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `other_need_types`
--
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('economic', NULL, '1', 'Financial Assistance');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('economic', NULL, '2', 'Job Placement');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('economic', NULL, '3', 'Skills Training');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('social', NULL, '4', 'Social Integration');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('social', NULL, '5', 'Family Support');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('social', NULL, '6', 'Recreational Activities');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('environmental', NULL, '7', 'Environmental Safety');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('environmental', NULL, '8', 'Waste Management');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('environmental', NULL, '9', 'Disaster Preparedness');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('others', NULL, '10', 'Technology Access');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('others', NULL, '11', 'Information Access');
INSERT INTO `other_need_types` (`category`, `description`, `id`, `name`) VALUES('others', NULL, '12', 'Cultural Activities');

-- --------------------------------------------------------
-- Table structure for `participant_notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `participant_notifications`;
CREATE TABLE `participant_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int NOT NULL,
  `participant_id` int NOT NULL,
  `delivery_method` varchar(20) DEFAULT NULL,
  `delivery_status` varchar(20) DEFAULT 'pending',
  `delivery_address` text,
  `email_address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `notification_type` enum('summons','hearing_notice','reminder') DEFAULT 'summons',
  `sent_at` datetime DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT '0',
  `confirmed_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_participant_type` (`blotter_case_id`,`participant_id`,`notification_type`),
  KEY `participant_id` (`participant_id`),
  KEY `idx_confirmation_token` (`confirmation_token`),
  KEY `idx_sent_confirmed` (`sent_at`,`confirmed`),
  CONSTRAINT `participant_notifications_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `participant_notifications_ibfk_2` FOREIGN KEY (`participant_id`) REFERENCES `blotter_participants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `participant_notifications`
--
INSERT INTO `participant_notifications` (`blotter_case_id`, `confirmation_token`, `confirmed`, `confirmed_at`, `delivery_address`, `delivery_method`, `delivery_status`, `email_address`, `id`, `notification_type`, `participant_id`, `phone_number`, `sent_at`) VALUES('1', NULL, '0', NULL, NULL, NULL, 'pending', 'external_1@placeholder.com', '1', 'summons', '6', NULL, NULL);
INSERT INTO `participant_notifications` (`blotter_case_id`, `confirmation_token`, `confirmed`, `confirmed_at`, `delivery_address`, `delivery_method`, `delivery_status`, `email_address`, `id`, `notification_type`, `participant_id`, `phone_number`, `sent_at`) VALUES('1', NULL, '1', NULL, NULL, NULL, 'pending', 'healthworker.tambubong@barangay.com', '2', 'summons', '1', NULL, NULL);
INSERT INTO `participant_notifications` (`blotter_case_id`, `confirmation_token`, `confirmed`, `confirmed_at`, `delivery_address`, `delivery_method`, `delivery_status`, `email_address`, `id`, `notification_type`, `participant_id`, `phone_number`, `sent_at`) VALUES('2', NULL, '1', NULL, NULL, NULL, 'pending', NULL, '3', 'summons', '2', NULL, NULL);
INSERT INTO `participant_notifications` (`blotter_case_id`, `confirmation_token`, `confirmed`, `confirmed_at`, `delivery_address`, `delivery_method`, `delivery_status`, `email_address`, `id`, `notification_type`, `participant_id`, `phone_number`, `sent_at`) VALUES('4', NULL, '0', NULL, NULL, NULL, 'pending', NULL, '4', 'summons', '4', NULL, NULL);
INSERT INTO `participant_notifications` (`blotter_case_id`, `confirmation_token`, `confirmed`, `confirmed_at`, `delivery_address`, `delivery_method`, `delivery_status`, `email_address`, `id`, `notification_type`, `participant_id`, `phone_number`, `sent_at`) VALUES('4', NULL, '1', NULL, NULL, NULL, 'pending', NULL, '5', 'summons', '5', NULL, NULL);

-- --------------------------------------------------------
-- Table structure for `password_history`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `password_history`;
CREATE TABLE `password_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id_created` (`user_id`,`created_at`),
  CONSTRAINT `password_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `password_reset_tokens`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`email`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`email`) REFERENCES `users` (`email`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_assets`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_assets`;
CREATE TABLE `person_assets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `asset_type_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_asset` (`person_id`,`asset_type_id`),
  KEY `asset_type_id` (`asset_type_id`),
  CONSTRAINT `person_assets_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_assets_ibfk_2` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_assets`
--
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Own family home with small lot', '1', '28');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Inherited family property', '2', '29');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Self-built house with rental apartment', '3', '32');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Family home with small garden', '4', '33');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Modern house in subdivision', '5', '34');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Old family home, well-maintained', '6', '36');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Carpenter-built family home', '7', '39');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Inherited ancestral home', '8', '43');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Recently purchased house', '9', '45');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('1', 'Senior citizen housing', '10', '30');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('1', 'Teacher quarters', '11', '31');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('1', 'Senior housing unit', '12', '38');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('3', '0.5 hectare rice field', '13', '30');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('3', '1 hectare mixed crops', '14', '47');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('3', '0.25 hectare vegetable garden', '15', '39');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Small sari-sari store', '16', '29');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Auto repair shop', '17', '32');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Engineering office space', '18', '34');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('6', 'Small fishpond operation', '19', '47');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('7', 'Tricycle unit', '20', '28');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('7', 'Jeepney unit', '21', '36');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('7', 'Auto repair equipment', '22', '32');
INSERT INTO `person_assets` (`asset_type_id`, `details`, `id`, `person_id`) VALUES('7', 'Sewing machines and equipment', '23', '33');

-- --------------------------------------------------------
-- Table structure for `person_community_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_community_problems`;
CREATE TABLE `person_community_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `desire_participate` tinyint(1) DEFAULT '0',
  `skills_to_share` tinyint(1) DEFAULT '0',
  `other_community` tinyint(1) DEFAULT '0',
  `other_community_details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `person_community_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_economic_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_economic_problems`;
CREATE TABLE `person_economic_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `loss_income` tinyint(1) DEFAULT '0',
  `unemployment` tinyint(1) DEFAULT '0',
  `skills_training` tinyint(1) DEFAULT '0',
  `skills_training_details` text,
  `livelihood` tinyint(1) DEFAULT '0',
  `livelihood_details` text,
  `other_economic` tinyint(1) DEFAULT '0',
  `other_economic_details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `person_economic_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_health_info`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_health_info`;
CREATE TABLE `person_health_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `health_condition` text,
  `has_maintenance` tinyint(1) DEFAULT '0',
  `maintenance_details` text,
  `high_cost_medicines` tinyint(1) DEFAULT '0',
  `lack_medical_professionals` tinyint(1) DEFAULT '0',
  `lack_sanitation_access` tinyint(1) DEFAULT '0',
  `lack_health_insurance` tinyint(1) DEFAULT '0',
  `lack_medical_facilities` tinyint(1) DEFAULT '0',
  `other_health_concerns` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `person_health_info_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_health_info`
--
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Hypertension, Diabetes', '1', '1', '0', '0', '0', '0', 'Amlodipine 5mg daily, Metformin 500mg twice daily', 'Difficulty walking long distances', '30');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Arthritis, High Blood Pressure', '1', '2', '0', '0', '1', '0', 'Ibuprofen 400mg as needed, Losartan 50mg daily', 'Joint pain especially during rainy season', '38');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Osteoporosis, Cataract', '0', '3', '1', '0', '1', '0', 'Calcium supplements, Eye drops', 'Blurred vision, frequent falls', '35');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Heart Disease, Kidney Problems', '1', '4', '0', '0', '0', '0', 'Multiple cardiac medications, Dialysis 3x/week', 'Requires frequent hospital visits', '43');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Depression, Insomnia', '0', '5', '1', '0', '1', '0', 'Antidepressants, Sleep aids', 'Social isolation, memory problems', '44');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('0', 'Allergic Rhinitis', '0', '6', '1', '0', '0', '0', NULL, 'Seasonal allergies', '28');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('0', 'Lower Back Pain', '0', '7', '0', '0', '1', '0', NULL, 'Work-related injury', '29');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('0', 'Migraine', '1', '8', '0', '0', '0', '0', NULL, 'Stress-related headaches', '32');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'Asthma', '0', '9', '0', '0', '0', '0', 'Salbutamol inhaler as needed', 'Triggered by dust and smoke', '33');
INSERT INTO `person_health_info` (`has_maintenance`, `health_condition`, `high_cost_medicines`, `id`, `lack_health_insurance`, `lack_medical_facilities`, `lack_medical_professionals`, `lack_sanitation_access`, `maintenance_details`, `other_health_concerns`, `person_id`) VALUES('1', 'High Cholesterol', '0', '10', '0', '0', '0', '0', 'Atorvastatin 20mg daily', 'Family history of heart disease', '36');

-- --------------------------------------------------------
-- Table structure for `person_health_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_health_problems`;
CREATE TABLE `person_health_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `condition_illness` tinyint(1) DEFAULT '0',
  `condition_illness_details` text,
  `high_cost_medicine` tinyint(1) DEFAULT '0',
  `lack_medical_professionals` tinyint(1) DEFAULT '0',
  `lack_sanitation` tinyint(1) DEFAULT '0',
  `lack_health_insurance` tinyint(1) DEFAULT '0',
  `inadequate_health_services` tinyint(1) DEFAULT '0',
  `other_health` tinyint(1) DEFAULT '0',
  `other_health_details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `person_health_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_housing_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_housing_problems`;
CREATE TABLE `person_housing_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `overcrowding` tinyint(1) DEFAULT '0',
  `no_permanent_housing` tinyint(1) DEFAULT '0',
  `independent_living` tinyint(1) DEFAULT '0',
  `lost_privacy` tinyint(1) DEFAULT '0',
  `squatters` tinyint(1) DEFAULT '0',
  `other_housing` tinyint(1) DEFAULT '0',
  `other_housing_details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `person_housing_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_identification`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_identification`;
CREATE TABLE `person_identification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `osca_id` varchar(50) DEFAULT NULL,
  `gsis_id` varchar(50) DEFAULT NULL,
  `sss_id` varchar(50) DEFAULT NULL,
  `tin_id` varchar(50) DEFAULT NULL,
  `philhealth_id` varchar(50) DEFAULT NULL,
  `other_id_type` varchar(50) DEFAULT NULL,
  `other_id_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `person_identification_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_identification`
--
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '1', 'OSCA-TAM-2024-001', NULL, NULL, '30', 'PH-123456789', '12-3456789-0', '123-456-789-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '2', 'OSCA-TAM-2024-002', NULL, NULL, '38', 'PH-234567890', '12-4567890-1', '234-567-890-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '3', 'OSCA-CAI-2024-001', NULL, NULL, '35', 'PH-345678901', '12-5678901-2', '345-678-901-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '4', 'OSCA-CAI-2024-002', NULL, NULL, '43', 'PH-456789012', '12-6789012-3', '456-789-012-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '5', 'OSCA-CAI-2024-003', NULL, NULL, '44', 'PH-567890123', '12-7890123-4', '567-890-123-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES('GSIS-001-234567', '6', NULL, NULL, NULL, '22', 'PH-678901234', '12-8901234-5', '678-901-234-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES('GSIS-002-345678', '7', NULL, NULL, NULL, '31', 'PH-789012345', '12-9012345-6', '789-012-345-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES('GSIS-003-456789', '8', NULL, NULL, NULL, '27', 'PH-890123456', '12-0123456-7', '890-123-456-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '9', NULL, NULL, NULL, '28', 'PH-901234567', '12-1234567-8', '901-234-567-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '10', NULL, NULL, NULL, '29', 'PH-012345678', '12-2345678-9', '012-345-678-000');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '11', NULL, NULL, NULL, '32', 'PH-123456789', '12-3456789-0', '123-456-789-111');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '12', NULL, NULL, NULL, '33', 'PH-234567890', '12-4567890-1', '234-567-890-111');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '13', NULL, NULL, NULL, '34', 'PH-345678901', '12-5678901-2', '345-678-901-111');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '14', NULL, NULL, NULL, '36', 'PH-456789012', '12-6789012-3', '456-789-012-111');
INSERT INTO `person_identification` (`gsis_id`, `id`, `osca_id`, `other_id_number`, `other_id_type`, `person_id`, `philhealth_id`, `sss_id`, `tin_id`) VALUES(NULL, '15', NULL, NULL, NULL, '37', 'PH-567890123', '12-7890123-4', '567-890-123-111');

-- --------------------------------------------------------
-- Table structure for `person_income_sources`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_income_sources`;
CREATE TABLE `person_income_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `source_type_id` int NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_income_source` (`person_id`,`source_type_id`),
  KEY `source_type_id` (`source_type_id`),
  CONSTRAINT `person_income_sources_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_income_sources_ibfk_2` FOREIGN KEY (`source_type_id`) REFERENCES `income_source_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_income_sources`
--
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('15000.00', 'Tricycle driving', '1', '28', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('12000.00', 'Sari-sari store business', '2', '29', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('25000.00', 'Public school teaching', '3', '31', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('18000.00', 'Auto repair shop', '4', '32', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('10000.00', 'Tailoring services', '5', '33', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('35000.00', 'Civil engineering', '6', '34', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('16000.00', 'Jeepney driving', '7', '36', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('20000.00', 'Electrical services', '8', '45', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('22000.00', 'Banking sector', '9', '46', '1');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('8000.00', 'Senior citizen pension', '10', '30', '2');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('12000.00', 'Retired carpenter pension', '11', '38', '2');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('6000.00', 'Widow pension', '12', '43', '2');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES(NULL, 'Monthly support from working children', '13', '35', '4');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES(NULL, 'Support from son working abroad', '14', '44', '4');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('15000.00', 'Husband tricycle driver', '15', '29', '5');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('10000.00', 'Wife seamstress', '16', '40', '5');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('10000.00', 'Husband fisherman', '17', '37', '5');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('5000.00', 'Small apartment rental', '18', '32', '8');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('8000.00', 'House rental income', '19', '34', '8');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('8000.00', 'Barangay health worker allowance', '20', '42', '11');
INSERT INTO `person_income_sources` (`amount`, `details`, `id`, `person_id`, `source_type_id`) VALUES('10000.00', 'Fishpond operations', '21', '47', '11');

-- --------------------------------------------------------
-- Table structure for `person_involvements`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_involvements`;
CREATE TABLE `person_involvements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `involvement_type_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_involvement` (`person_id`,`involvement_type_id`),
  KEY `involvement_type_id` (`involvement_type_id`),
  CONSTRAINT `person_involvements_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_involvements_ibfk_2` FOREIGN KEY (`involvement_type_id`) REFERENCES `involvement_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_involvements`
--
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Barangay health worker', '1', '1', '22');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Community health volunteer', '2', '1', '27');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Education program volunteer', '3', '2', '31');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Skills training instructor', '4', '2', '34');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Monthly cleanup drive participant', '5', '3', '28');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Garden maintenance volunteer', '6', '3', '29');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Street sweeping coordinator', '7', '3', '36');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Homeowners association president', '8', '4', '32');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Senior citizen group leader', '9', '4', '43');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Youth organization advisor', '10', '4', '45');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Senior citizen companion', '11', '6', '35');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Elderly check-up volunteer', '12', '6', '38');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Emergency response team', '13', '7', '29');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Disaster preparedness volunteer', '14', '7', '39');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Church lector and volunteer', '15', '8', '30');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Prayer group leader', '16', '8', '33');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Religious education teacher', '17', '8', '44');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Church choir member', '18', '8', '46');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Education scholarship sponsor', '19', '10', '34');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Community event sponsor', '20', '10', '37');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Barangay watch volunteer', '21', '12', '40');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Community garden coordinator', '22', '12', '42');
INSERT INTO `person_involvements` (`details`, `id`, `involvement_type_id`, `person_id`) VALUES('Livelihood training facilitator', '23', '12', '47');

-- --------------------------------------------------------
-- Table structure for `person_living_arrangements`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_living_arrangements`;
CREATE TABLE `person_living_arrangements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `arrangement_type_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_arrangement` (`person_id`,`arrangement_type_id`),
  KEY `arrangement_type_id` (`arrangement_type_id`),
  CONSTRAINT `person_living_arrangements_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_living_arrangements_ibfk_2` FOREIGN KEY (`arrangement_type_id`) REFERENCES `living_arrangement_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_living_arrangements`
--
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Living with spouse and children', '1', '28');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Living with spouse only', '2', '29');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Nuclear family setup', '3', '32');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'With husband and extended family', '4', '33');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'With wife and children', '5', '36');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Elderly couple', '6', '39');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('2', 'Newly married couple', '7', '45');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Living with adult children', '8', '30');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Supported by children', '9', '38');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('4', 'Dependent on children', '10', '43');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('5', 'Multi-generational household', '11', '35');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('5', 'Caring for grandchildren', '12', '44');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('8', 'Living with cousin family', '13', '31');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('8', 'Extended family arrangement', '14', '37');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('8', 'Boarding with relatives', '15', '46');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('1', 'Widow living independently', '16', '35');
INSERT INTO `person_living_arrangements` (`arrangement_type_id`, `details`, `id`, `person_id`) VALUES('1', 'Single professional', '17', '40');

-- --------------------------------------------------------
-- Table structure for `person_other_needs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_other_needs`;
CREATE TABLE `person_other_needs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `need_type_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_other_need` (`person_id`,`need_type_id`),
  KEY `need_type_id` (`need_type_id`),
  CONSTRAINT `person_other_needs_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_other_needs_ibfk_2` FOREIGN KEY (`need_type_id`) REFERENCES `other_need_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_problems`;
CREATE TABLE `person_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `problem_category_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_problem` (`person_id`,`problem_category_id`),
  KEY `problem_category_id` (`problem_category_id`),
  CONSTRAINT `person_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_problems_ibfk_2` FOREIGN KEY (`problem_category_id`) REFERENCES `problem_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `person_skills`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_skills`;
CREATE TABLE `person_skills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `skill_type_id` int NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_person_skill` (`person_id`,`skill_type_id`),
  KEY `skill_type_id` (`skill_type_id`),
  CONSTRAINT `person_skills_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `person_skills_ibfk_2` FOREIGN KEY (`skill_type_id`) REFERENCES `skill_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `person_skills`
--
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Health worker certification', '1', '22', '1');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Nursing degree and experience', '2', '27', '1');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('First aid training', '3', '37', '1');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Elementary education degree', '4', '31', '2');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Health education and training', '5', '20', '2');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Automotive driving and mechanics', '6', '28', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Auto repair and maintenance', '7', '32', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Tailoring and dressmaking', '8', '33', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Carpentry and woodworking', '9', '39', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Electrical installation and repair', '10', '45', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Fishpond management', '11', '47', '10');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Rice farming techniques', '12', '30', '7');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Vegetable gardening', '13', '40', '7');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Food preparation and catering', '14', '29', '9');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Traditional Filipino cooking', '15', '35', '9');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Baking and pastry making', '16', '44', '9');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Traditional embroidery', '17', '33', '11');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Handicraft making', '18', '46', '11');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Civil engineering and construction', '19', '34', '12');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Public transportation operation', '20', '36', '13');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Senior citizen peer counseling', '21', '38', '13');
INSERT INTO `person_skills` (`details`, `id`, `person_id`, `skill_type_id`) VALUES('Community health education', '22', '42', '13');

-- --------------------------------------------------------
-- Table structure for `person_social_problems`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `person_social_problems`;
CREATE TABLE `person_social_problems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `loneliness` tinyint(1) DEFAULT '0',
  `isolation` tinyint(1) DEFAULT '0',
  `neglect` tinyint(1) DEFAULT '0',
  `recreational` tinyint(1) DEFAULT '0',
  `senior_friendly` tinyint(1) DEFAULT '0',
  `other_social` tinyint(1) DEFAULT '0',
  `other_social_details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `person_social_problems_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `personal_access_tokens`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_tokenable` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `persons`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `persons`;
CREATE TABLE `persons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `birth_date` date NOT NULL,
  `birth_place` varchar(100) NOT NULL,
  `gender` enum('MALE','FEMALE') NOT NULL,
  `civil_status` enum('SINGLE','MARRIED','WIDOW/WIDOWER','SEPARATED') NOT NULL,
  `citizenship` varchar(50) DEFAULT 'Filipino',
  `religion` varchar(50) DEFAULT NULL,
  `education_level` enum('NOT ATTENDED ANY SCHOOL','ELEMENTARY LEVEL','ELEMENTARY GRADUATE','HIGH SCHOOL LEVEL','HIGH SCHOOL GRADUATE','VOCATIONAL','COLLEGE LEVEL','COLLEGE GRADUATE','POST GRADUATE') DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `monthly_income` decimal(10,2) DEFAULT NULL,
  `years_of_residency` int DEFAULT '0',
  `nhts_pr_listahanan` tinyint(1) DEFAULT '0',
  `indigenous_people` tinyint(1) DEFAULT '0',
  `pantawid_beneficiary` tinyint(1) DEFAULT '0',
  `resident_type` enum('REGULAR','SENIOR','PWD') DEFAULT 'REGULAR',
  `contact_number` varchar(20) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `persons_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `persons`
--
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1990-01-01', 'Manila', 'Filipino', 'SINGLE', NULL, NULL, 'System', 'MALE', '1', '0', '0', 'Programmer', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '1', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1985-01-01', 'Quezon City', 'Filipino', 'MARRIED', NULL, NULL, 'Super', 'FEMALE', '2', '0', '0', 'Administrator', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '2', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1980-01-01', 'San Rafael', 'Filipino', 'MARRIED', NULL, NULL, 'Barangay', 'MALE', '3', '0', '0', 'Administrator', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '3', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1970-01-01', 'San Rafael', 'Filipino', 'MARRIED', NULL, NULL, 'Juan', 'MALE', '4', '0', '0', 'Dela Cruz', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '4', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1990-01-01', 'Manila', 'Filipino', 'SINGLE', NULL, NULL, 'Test', 'MALE', '5', '0', '0', 'Resident', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '5', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1992-05-15', 'San Rafael', 'Filipino', 'SINGLE', NULL, NULL, 'Neil', 'MALE', '6', '0', '0', 'Ardrey', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '6', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1975-03-15', 'Bulacan', 'Filipino', 'MARRIED', NULL, NULL, 'Maria', 'FEMALE', '7', '0', '0', 'Santos', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '7', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1970-08-22', 'Bulacan', 'Filipino', 'MARRIED', NULL, NULL, 'Roberto', 'MALE', '8', '0', '0', 'Reyes', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '8', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1968-11-10', 'Bulacan', 'Filipino', 'MARRIED', NULL, NULL, 'Ricardo', 'MALE', '9', '0', '0', 'Morales', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '9', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1968-11-10', 'Bulacan', 'Filipino', 'MARRIED', NULL, NULL, 'tite', 'MALE', '10', '0', '0', 'flores', NULL, NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, '10', '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1995-02-14', 'San Rafael', 'Filipino', 'SINGLE', '09112233445', NULL, 'Luis', 'MALE', '11', '0', '0', 'Santos', 'Manalo', NULL, '0', 'Engineer', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1988-11-30', 'San Rafael', 'Filipino', 'MARRIED', '09223344556', NULL, 'Sofia', 'FEMALE', '12', '0', '0', 'Reyes', 'Alcantara', NULL, '0', 'Business Owner', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1972-07-22', 'San Rafael', 'Filipino', 'WIDOW/WIDOWER', '09334455667', NULL, 'Miguel', 'MALE', '13', '0', '0', 'Cruz', 'Tolentino', NULL, '0', 'Fisherman', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1980-05-15', 'San Rafael', 'Filipino', 'MARRIED', '09123456789', NULL, 'Carlos', 'MALE', '14', '0', '0', 'Dela Cruz', 'Santos', NULL, '0', 'Farmer', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1985-08-20', 'San Rafael', 'Filipino', 'MARRIED', '09987654321', NULL, 'Elena', 'FEMALE', '15', '0', '0', 'Santos', 'Garcia', NULL, '0', 'Teacher', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1975-12-10', 'San Rafael', 'Filipino', 'SINGLE', '09111222333', NULL, 'Pedro', 'MALE', '16', '0', '0', 'Gonzales', 'Ramos', NULL, '0', 'Driver', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1990-03-25', 'San Rafael', 'Filipino', 'SINGLE', '09444555666', NULL, 'Ana', 'FEMALE', '17', '0', '0', 'Reyes', 'Flores', NULL, '0', 'Nurse', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1990-03-25', 'San Rafael', 'Filipino', 'SINGLE', '09344555666', NULL, 'tite', 'FEMALE', '18', '0', '0', 'Reyes', 'Flores', NULL, '0', 'Nurse', '0', NULL, 'REGULAR', NULL, NULL, '0');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1982-03-15', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234501', 'COLLEGE GRADUATE', 'Maria', 'FEMALE', '19', '0', '0', 'Rodriguez', 'Santos', '25000.00', '0', 'Barangay Secretary', '0', NULL, 'REGULAR', NULL, '11', '15');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1978-08-22', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234502', 'COLLEGE GRADUATE', 'Antonio', 'MALE', '20', '0', '0', 'Lopez', 'Cruz', '28000.00', '0', 'Barangay Treasurer', '0', NULL, 'REGULAR', NULL, '12', '18');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1985-12-10', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09171234503', 'COLLEGE GRADUATE', 'Carmen', 'FEMALE', '21', '0', '0', 'Villanueva', 'Dela Cruz', '22000.00', '0', 'Barangay Councilor', '0', NULL, 'REGULAR', NULL, '13', '10');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1980-04-18', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234504', 'HIGH SCHOOL GRADUATE', 'Roberto', 'MALE', '22', '0', '0', 'Fernandez', 'Mendoza', '22000.00', '0', 'Barangay Councilor', '0', NULL, 'REGULAR', NULL, '14', '12');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1975-09-05', 'Manila', 'Filipino', 'MARRIED', '09171234505', 'POST GRADUATE', 'Elena', 'FEMALE', '23', '0', '0', 'Cruz', 'Garcia', '35000.00', '0', 'Health Worker', '0', NULL, 'REGULAR', NULL, '15', '8');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1979-06-12', 'San Rafael, Bulacan', 'Filipino', 'WIDOW/WIDOWER', '09171234506', 'COLLEGE GRADUATE', 'Luz', 'FEMALE', '24', '0', '0', 'Mercado', 'Santos', '24000.00', '0', 'Barangay Secretary', '0', NULL, 'REGULAR', NULL, '16', '20');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1983-11-28', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234507', 'COLLEGE GRADUATE', 'Jose', 'MALE', '25', '0', '0', 'Ramirez', 'Cruz', '27000.00', '0', 'Barangay Treasurer', '0', NULL, 'REGULAR', NULL, '17', '16');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1987-02-14', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09171234508', 'COLLEGE GRADUATE', 'Alma', 'FEMALE', '26', '0', '0', 'Torres', 'Reyes', '21000.00', '0', 'Barangay Councilor', '0', NULL, 'REGULAR', NULL, '18', '8');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1975-07-30', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234509', 'COLLEGE GRADUATE', 'Benjamin', 'MALE', '27', '0', '0', 'Aguilar', 'Lopez', '30000.00', '0', 'Barangay Chairperson', '0', NULL, 'REGULAR', NULL, '19', '22');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1981-10-08', 'Quezon City', 'Filipino', 'MARRIED', '09171234510', 'COLLEGE GRADUATE', 'Rosa', 'FEMALE', '28', '0', '0', 'Delgado', 'Martinez', '32000.00', '0', 'Health Worker', '0', NULL, 'REGULAR', NULL, '20', '6');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1990-01-15', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09171234567', 'HIGH SCHOOL GRADUATE', 'Juan', 'MALE', '29', '0', '0', 'Santos', 'Cruz', '15000.00', '0', 'Tricycle Driver', '0', NULL, 'REGULAR', NULL, '21', '25');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1988-05-20', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09182345678', 'COLLEGE LEVEL', 'Maria', 'FEMALE', '30', '0', '0', 'Garcia', 'Reyes', '12000.00', '0', 'Sari-sari Store Owner', '0', NULL, 'REGULAR', NULL, '22', '20');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1965-03-08', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09193456789', 'ELEMENTARY GRADUATE', 'Pedro', 'MALE', '31', '0', '0', 'Dela Cruz', 'Santos', '8000.00', '0', 'Farmer', '0', NULL, 'SENIOR', NULL, '23', '45');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1992-07-12', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09204567890', 'COLLEGE GRADUATE', 'Ana', 'FEMALE', '32', '0', '0', 'Reyes', 'Garcia', '25000.00', '0', 'Teacher', '0', NULL, 'REGULAR', NULL, '24', '18');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1985-11-25', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09215678901', 'VOCATIONAL', 'Carlos', 'MALE', '33', '0', '0', 'Mendoza', 'Torres', '18000.00', '0', 'Mechanic', '0', NULL, 'REGULAR', NULL, '25', '15');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1989-04-18', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09226789012', 'HIGH SCHOOL GRADUATE', 'Rosa', 'FEMALE', '34', '0', '0', 'Martinez', 'Santos', '10000.00', '0', 'Seamstress', '0', NULL, 'REGULAR', NULL, '26', '22');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1987-08-30', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09237890123', 'COLLEGE GRADUATE', 'Miguel', 'MALE', '35', '0', '0', 'Torres', 'Cruz', '35000.00', '0', 'Engineer', '0', NULL, 'REGULAR', NULL, '27', '12');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1970-12-02', 'San Rafael, Bulacan', 'Filipino', 'WIDOW/WIDOWER', '09248901234', 'HIGH SCHOOL GRADUATE', 'Carmen', 'FEMALE', '36', '0', '0', 'Flores', 'Dela Cruz', '6000.00', '0', 'Vendor', '0', NULL, 'SENIOR', NULL, '28', '35');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1991-06-14', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09259012345', 'COLLEGE LEVEL', 'Ricardo', 'MALE', '37', '0', '0', 'Santos', 'Lopez', '16000.00', '0', 'Security Guard', '0', NULL, 'REGULAR', NULL, '29', '10');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1993-09-22', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09260123456', 'COLLEGE GRADUATE', 'Elena', 'FEMALE', '38', '0', '0', 'Cruz', 'Martinez', '28000.00', '0', 'Nurse', '0', NULL, 'REGULAR', NULL, '30', '8');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1955-02-14', 'San Rafael, Bulacan', 'Filipino', 'WIDOW/WIDOWER', '09301234567', 'ELEMENTARY LEVEL', 'Josefa', 'FEMALE', '39', '0', '0', 'Rivera', 'Santos', '3000.00', '1', 'Retired', '0', NULL, 'SENIOR', NULL, NULL, '50');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1958-07-19', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09302345678', 'HIGH SCHOOL LEVEL', 'Manuel', 'MALE', '40', '0', '0', 'Cruz', 'Garcia', '12000.00', '0', 'Carpenter', '0', NULL, 'SENIOR', NULL, NULL, '40');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1962-11-03', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09303456789', 'ELEMENTARY GRADUATE', 'Linda', 'FEMALE', '41', '0', '0', 'Santos', 'Torres', '0.00', '1', 'Housewife', '1', NULL, 'SENIOR', NULL, NULL, '38');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1995-03-28', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09304567890', 'HIGH SCHOOL GRADUATE', 'Roberto', 'MALE', '42', '0', '0', 'Villanueva', 'Cruz', '14000.00', '0', 'Construction Worker', '0', NULL, 'REGULAR', NULL, NULL, '12');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1980-09-15', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09305678901', 'COLLEGE LEVEL', 'Gloria', 'FEMALE', '43', '0', '0', 'Reyes', 'Mendoza', '8000.00', '0', 'Barangay Health Worker', '0', NULL, 'REGULAR', NULL, NULL, '25');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1960-01-22', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09306789012', 'HIGH SCHOOL GRADUATE', 'Fernando', 'MALE', '44', '0', '0', 'Lopez', 'Santos', '16000.00', '0', 'Jeepney Driver', '0', NULL, 'SENIOR', NULL, NULL, '35');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1963-05-17', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09307890123', 'ELEMENTARY GRADUATE', 'Esperanza', 'FEMALE', '45', '0', '0', 'Martinez', 'Garcia', '0.00', '1', 'Housewife', '1', NULL, 'SENIOR', NULL, NULL, '33');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1988-12-11', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09308901234', 'VOCATIONAL', 'Antonio', 'MALE', '46', '0', '0', 'Torres', 'Reyes', '20000.00', '0', 'Electrician', '0', NULL, 'REGULAR', NULL, NULL, '18');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1994-04-06', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '09309012345', 'COLLEGE GRADUATE', 'Maricel', 'FEMALE', '47', '0', '0', 'Aguilar', 'Cruz', '22000.00', '0', 'Bank Teller', '0', NULL, 'REGULAR', NULL, NULL, '8');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('1975-08-13', 'San Rafael, Bulacan', 'Filipino', 'MARRIED', '09310123456', 'HIGH SCHOOL GRADUATE', 'Domingo', 'MALE', '48', '0', '0', 'Delgado', 'Torres', '10000.00', '1', 'Fisherman', '1', NULL, 'REGULAR', NULL, NULL, '28');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2010-03-15', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Miguel Jr.', 'MALE', '49', '0', '0', 'Garcia', 'Santos', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '14');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2012-07-20', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Sofia', 'FEMALE', '50', '0', '0', 'Santos', 'Cruz', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '12');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2015-01-10', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Juan Carlo', 'MALE', '51', '0', '0', 'Dela Cruz', 'Reyes', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '9');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2008-09-25', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'HIGH SCHOOL LEVEL', 'Isabella', 'FEMALE', '52', '0', '0', 'Mendoza', 'Garcia', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '16');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2011-05-18', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Luis', 'MALE', '53', '0', '0', 'Martinez', 'Santos', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '13');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2013-11-30', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Maria Luisa', 'FEMALE', '54', '0', '0', 'Torres', 'Cruz', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '11');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2009-02-14', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'HIGH SCHOOL LEVEL', 'Carlos Eduardo', 'MALE', '55', '0', '0', 'Santos', 'Dela Cruz', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '15');
INSERT INTO `persons` (`birth_date`, `birth_place`, `citizenship`, `civil_status`, `contact_number`, `education_level`, `first_name`, `gender`, `id`, `indigenous_people`, `is_archived`, `last_name`, `middle_name`, `monthly_income`, `nhts_pr_listahanan`, `occupation`, `pantawid_beneficiary`, `religion`, `resident_type`, `suffix`, `user_id`, `years_of_residency`) VALUES('2016-06-08', 'San Rafael, Bulacan', 'Filipino', 'SINGLE', '', 'ELEMENTARY LEVEL', 'Anna Marie', 'FEMALE', '56', '0', '0', 'Cruz', 'Lopez', NULL, '0', NULL, '0', NULL, 'REGULAR', NULL, NULL, '8');

-- --------------------------------------------------------
-- Table structure for `problem_categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `problem_categories`;
CREATE TABLE `problem_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_type` enum('health','economic','social','housing') NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `problem_categories`
--
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '1', 'Lack/No Health Insurance/s');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '2', 'Inadequate Health Services');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '3', 'Lack of Hospitals/Medical Facilities');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '4', 'High Cost of Medicines');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '5', 'Lack of Medical Professionals');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('health', NULL, '6', 'Lack of Sanitation Access');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '7', 'Overcrowding in the Family Home');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '8', 'No Permanent Housing');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '9', 'Longing for Independent Living/Quiet Atmosphere');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '10', 'Lost Privacy');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '11', 'Living in Squatter Area');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('housing', NULL, '12', 'High Cost Rent');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('economic', NULL, '13', 'Insufficient Income');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('economic', NULL, '14', 'Unemployment');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('economic', NULL, '15', 'High Cost of Living');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('economic', NULL, '16', 'Skills/Capability Training');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('economic', NULL, '17', 'Livelihood opportunities');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '18', 'Lack of Support from Family');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '19', 'Limited Social Interaction');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '20', 'Difficulty in Accessing Services');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '21', 'Feeling of neglect & rejection');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '22', 'Feeling of helplessness & worthlessness');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '23', 'Feeling of loneliness & isolation');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '24', 'Inadequate leisure/recreational activities');
INSERT INTO `problem_categories` (`category_type`, `description`, `id`, `name`) VALUES('social', NULL, '25', 'Senior Citizen Friendly Environment');

-- --------------------------------------------------------
-- Table structure for `problems_needs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `problems_needs`;
CREATE TABLE `problems_needs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `lack_income` tinyint(1) DEFAULT '0',
  `unemployment` tinyint(1) DEFAULT '0',
  `economic_others` tinyint(1) DEFAULT '0',
  `economic_others_specify` varchar(100) DEFAULT NULL,
  `loneliness` tinyint(1) DEFAULT '0',
  `isolation` tinyint(1) DEFAULT '0',
  `neglect` tinyint(1) DEFAULT '0',
  `lack_health_insurance` tinyint(1) DEFAULT '0',
  `inadequate_health_services` tinyint(1) DEFAULT '0',
  `lack_medical_facilities` tinyint(1) DEFAULT '0',
  `overcrowding` tinyint(1) DEFAULT '0',
  `no_permanent_housing` tinyint(1) DEFAULT '0',
  `independent_living` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `problems_needs_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `purok`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `purok`;
CREATE TABLE `purok` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barangay_purok` (`barangay_id`,`name`),
  CONSTRAINT `purok_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `purok`
--
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('3', '6', 'Purok A - Sunshine');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('3', '7', 'Purok B - Harmony');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('3', '8', 'Purok C - Progress');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('3', '9', 'Purok D - Victory');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('32', '1', 'Purok 1 - Riverside');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('32', '2', 'Purok 2 - Central');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('32', '3', 'Purok 3 - Mountain View');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('32', '4', 'Purok 4 - Garden');
INSERT INTO `purok` (`barangay_id`, `id`, `name`) VALUES('32', '5', 'Purok 5 - Unity');

-- --------------------------------------------------------
-- Table structure for `relationship_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `relationship_types`;
CREATE TABLE `relationship_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `relationship_types`
--
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '1', 'HEAD');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '2', 'SPOUSE');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '3', 'CHILD');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '4', 'PARENT');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '5', 'SIBLING');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '6', 'GRANDCHILD');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '7', 'OTHER RELATIVE');
INSERT INTO `relationship_types` (`description`, `id`, `name`) VALUES(NULL, '8', 'NON-RELATIVE');

-- --------------------------------------------------------
-- Table structure for `roles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `roles`
--
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('System developer with full access', '1', 'programmer');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Administrative account with system-wide access', '2', 'super_admin');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Lead barangay official', '3', 'barangay_captain');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Administrative official for barangay operations', '4', 'barangay_secretary');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Financial official for barangay funds', '5', 'barangay_treasurer');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Elected barangay council member', '6', 'barangay_councilor');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Leads blottercases', '7', 'barangay_chairperson');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Regular barangay resident', '8', 'resident');
INSERT INTO `roles` (`description`, `id`, `name`) VALUES('Health worker for census', '9', 'health_worker');

-- --------------------------------------------------------
-- Table structure for `schedule_notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `schedule_notifications`;
CREATE TABLE `schedule_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schedule_proposal_id` int NOT NULL,
  `notified_user_id` int NOT NULL,
  `notification_type` enum('proposal','confirmation','rejection') NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `schedule_proposal_id` (`schedule_proposal_id`),
  KEY `idx_schedule_notifications_user` (`notified_user_id`,`is_read`),
  CONSTRAINT `schedule_notifications_ibfk_1` FOREIGN KEY (`schedule_proposal_id`) REFERENCES `schedule_proposals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_notifications_ibfk_2` FOREIGN KEY (`notified_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `schedule_proposals`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `schedule_proposals`;
CREATE TABLE `schedule_proposals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blotter_case_id` int DEFAULT NULL,
  `proposed_by_user_id` int DEFAULT NULL,
  `proposed_by_role_id` int NOT NULL,
  `proposed_date` date NOT NULL,
  `proposed_time` time NOT NULL,
  `hearing_location` varchar(255) NOT NULL,
  `presiding_officer` varchar(100) NOT NULL,
  `presiding_officer_position` varchar(50) NOT NULL,
  `status` enum('proposed','user_confirmed','captain_confirmed','both_confirmed','conflict','pending_user_confirmation','pending_captain_approval','pending_chief_approval','all_confirmed','cancelled','officer_conflict') NOT NULL DEFAULT 'proposed',
  `notification_sent` tinyint(1) DEFAULT '0',
  `notification_sent_at` datetime DEFAULT NULL,
  `user_confirmed` tinyint(1) DEFAULT '0',
  `user_confirmed_at` datetime DEFAULT NULL,
  `captain_confirmed` tinyint(1) DEFAULT '0',
  `chief_confirmed` tinyint(1) DEFAULT '0',
  `chief_confirmed_at` datetime DEFAULT NULL,
  `captain_confirmed_at` datetime DEFAULT NULL,
  `confirmed_by_role` int DEFAULT NULL,
  `user_remarks` text,
  `captain_remarks` text,
  `chief_remarks` text,
  `conflict_reason` text,
  `complainant_confirmed` tinyint(1) DEFAULT '0',
  `respondent_confirmed` tinyint(1) DEFAULT '0',
  `witness_confirmed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status_updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blotter_case_id` (`blotter_case_id`),
  KEY `proposed_by_user_id` (`proposed_by_user_id`),
  KEY `confirmed_by_role` (`confirmed_by_role`),
  KEY `proposed_by_role_id` (`proposed_by_role_id`),
  KEY `idx_schedule_proposals_status` (`status`),
  CONSTRAINT `schedule_proposals_ibfk_1` FOREIGN KEY (`blotter_case_id`) REFERENCES `blotter_cases` (`id`),
  CONSTRAINT `schedule_proposals_ibfk_2` FOREIGN KEY (`proposed_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `schedule_proposals_ibfk_3` FOREIGN KEY (`confirmed_by_role`) REFERENCES `roles` (`id`),
  CONSTRAINT `schedule_proposals_ibfk_4` FOREIGN KEY (`proposed_by_role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `service_categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `service_categories`;
CREATE TABLE `service_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barangay_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(50) DEFAULT 'fa-cog',
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `service_categories_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `service_categories`
--
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('32', 'All document request and certification services', '1', 'fa-file-text', '1', '1', 'Document Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('32', 'Health and medical related services', '2', 'fa-heartbeat', '2', '1', 'Health Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('32', 'Blotter, mediation and legal assistance', '3', 'fa-gavel', '3', '1', 'Legal Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('32', 'Events, programs and community activities', '4', 'fa-users', '4', '1', 'Community Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('32', 'Business permits and commercial services', '5', 'fa-briefcase', '5', '1', 'Business Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('3', 'All document request and certification services', '1', 'fa-file-text', '6', '1', 'Document Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('3', 'Health and medical related services', '2', 'fa-heartbeat', '7', '1', 'Health Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('3', 'Blotter, mediation and legal assistance', '3', 'fa-gavel', '8', '1', 'Legal Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('3', 'Farming and livelihood support services', '4', 'fa-leaf', '9', '1', 'Agricultural Services');
INSERT INTO `service_categories` (`barangay_id`, `description`, `display_order`, `icon`, `id`, `is_active`, `name`) VALUES('3', 'Social welfare and assistance programs', '5', 'fa-heart', '10', '1', 'Social Services');

-- --------------------------------------------------------
-- Table structure for `service_request_attachments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `service_request_attachments`;
CREATE TABLE `service_request_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`),
  CONSTRAINT `service_request_attachments_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `service_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `service_requests`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `service_requests`;
CREATE TABLE `service_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  `status` enum('pending','processing','completed','rejected','cancelled') DEFAULT 'pending',
  `remarks` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `service_requests_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `custom_services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `service_requirements`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `service_requirements`;
CREATE TABLE `service_requirements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `is_required` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `service_requirements_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `custom_services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `sessions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `payload` longtext NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sessions_user_id` (`user_id`),
  KEY `idx_sessions_last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `skill_types`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `skill_types`;
CREATE TABLE `skill_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skill_types`
--
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '1', 'Medical');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '2', 'Teaching');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '3', 'Legal Services');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '4', 'Dental');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '5', 'Counseling');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '6', 'Evangelization');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '7', 'Farming');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '8', 'Fishing');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '9', 'Cooking');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '10', 'Vocational');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '11', 'Arts');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '12', 'Engineering');
INSERT INTO `skill_types` (`description`, `id`, `name`) VALUES(NULL, '13', 'Others');

-- --------------------------------------------------------
-- Table structure for `skills`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `skills`;
CREATE TABLE `skills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `dental` tinyint(1) DEFAULT '0',
  `counseling` tinyint(1) DEFAULT '0',
  `evangelization` tinyint(1) DEFAULT '0',
  `farming` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`),
  CONSTRAINT `skills_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `temporary_records`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `temporary_records`;
CREATE TABLE `temporary_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `last_name` varchar(100) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `house_number` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `barangay_id` varchar(100) NOT NULL,
  `municipality` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `id_type` varchar(100) NOT NULL,
  `id_number` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `date_of_birth` date NOT NULL,
  `place_of_birth` varchar(255) NOT NULL,
  `months_residency` int NOT NULL,
  `days_residency` int NOT NULL,
  `is_archived` varchar(50) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------
-- Table structure for `user_roles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  `barangay_id` int NOT NULL,
  `start_term_date` date DEFAULT NULL,
  `end_term_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_role_barangay` (`user_id`,`role_id`,`barangay_id`),
  KEY `role_id` (`role_id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_3` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_roles`
--
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('1', NULL, '1', '1', '1', NULL, '1');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('1', NULL, '2', '1', '2', NULL, '2');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '3', '1', '4', NULL, '3');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', '2025-12-31', '4', '1', '3', '2023-01-01', '4');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '5', '1', '8', NULL, '5');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '6', '1', '8', NULL, '6');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('18', '2025-12-31', '7', '1', '3', '2023-01-01', '7');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', '2025-12-31', '8', '1', '3', '2023-01-01', '8');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('1', '2025-12-31', '9', '1', '3', '2023-01-01', '9');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', '2025-12-31', '10', '1', '4', '2023-01-01', '11');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', '2025-12-31', '11', '1', '5', '2023-01-01', '12');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', '2025-12-31', '12', '1', '6', '2023-01-01', '13');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', '2025-12-31', '13', '1', '6', '2023-01-01', '14');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '14', '1', '9', NULL, '15');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', '2025-12-31', '15', '1', '4', '2023-01-01', '16');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', '2025-12-31', '16', '1', '5', '2023-01-01', '17');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', '2025-12-31', '17', '1', '6', '2023-01-01', '18');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', '2025-12-31', '18', '1', '7', '2023-01-01', '19');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '19', '1', '9', NULL, '20');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '20', '1', '8', NULL, '21');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '21', '1', '8', NULL, '22');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '22', '1', '8', NULL, '23');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '23', '1', '8', NULL, '24');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('32', NULL, '24', '1', '8', NULL, '25');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '25', '1', '8', NULL, '26');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '26', '1', '8', NULL, '27');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '27', '1', '8', NULL, '28');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '28', '1', '8', NULL, '29');
INSERT INTO `user_roles` (`barangay_id`, `end_term_date`, `id`, `is_active`, `role_id`, `start_term_date`, `user_id`) VALUES('3', NULL, '29', '1', '8', NULL, '30');

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role_id` int DEFAULT '8',
  `barangay_id` int DEFAULT '1',
  `id_expiration_date` date DEFAULT NULL,
  `id_type` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `gender` enum('Male','Female','Others') DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `verification_token` varchar(32) DEFAULT NULL,
  `verification_expiry` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `start_term_date` date DEFAULT NULL,
  `end_term_date` date DEFAULT NULL,
  `id_image_path` varchar(255) DEFAULT 'default.png',
  `signature_image_path` varchar(255) DEFAULT NULL,
  `esignature_path` varchar(255) DEFAULT NULL,
  `govt_id_image` longblob,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `chief_officer_esignature_path` longblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  KEY `role_id` (`role_id`),
  KEY `barangay_id` (`barangay_id`),
  KEY `idx_users_esignature` (`esignature_path`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('1', NULL, 'programmer@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'System', 'Male', NULL, '1', NULL, 'default.png', NULL, NULL, '1', NULL, 'Programmer', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '1', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('1', NULL, 'superadmin@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Super', 'Female', NULL, '2', NULL, 'default.png', NULL, NULL, '1', NULL, 'Administrator', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '2', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'barangayadmin@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Barangay', 'Male', NULL, '3', NULL, 'default.png', NULL, NULL, '1', NULL, 'Administrator', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '4', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'captain.tambubong@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Juan', 'Male', NULL, '4', NULL, 'default.png', NULL, NULL, '1', NULL, 'Dela Cruz', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '3', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'resident1@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Test', 'Male', NULL, '5', NULL, 'default.png', NULL, NULL, '1', NULL, 'Resident', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'neilardrey14@gmail.com', '2025-06-06 20:48:00', NULL, NULL, 'Neil', 'Male', NULL, '6', NULL, 'default.png', NULL, NULL, '1', NULL, 'Ardrey', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('18', NULL, 'captain.pantubig@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Maria', 'Female', NULL, '7', NULL, 'default.png', NULL, NULL, '1', NULL, 'Santos', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '3', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'captain.caingin@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Roberto', 'Male', NULL, '8', NULL, 'default.png', NULL, NULL, '1', NULL, 'Reyes', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '3', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'chiefOfficer.tambubong@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Ricardo', 'Male', NULL, '9', NULL, 'default.png', NULL, NULL, '1', NULL, 'Morales', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '7', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'healthworker.tambubong@barangay.com', '2025-06-06 20:48:00', NULL, NULL, 'Ricardo', 'Male', NULL, '10', NULL, 'default.png', NULL, NULL, '1', NULL, 'Morales', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'secretary.tambubong@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Maria', 'Female', NULL, '11', NULL, 'default.png', NULL, NULL, '1', NULL, 'Rodriguez', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '4', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'treasurer.tambubong@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Antonio', 'Male', NULL, '12', NULL, 'default.png', NULL, NULL, '1', NULL, 'Lopez', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '5', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'councilor1.tambubong@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Carmen', 'Female', NULL, '13', NULL, 'default.png', NULL, NULL, '1', NULL, 'Villanueva', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '6', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'councilor2.tambubong@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Roberto', 'Male', NULL, '14', NULL, 'default.png', NULL, NULL, '1', NULL, 'Fernandez', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '6', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'healthworker1.tambubong@barangay.com', '2025-06-06 20:48:03', NULL, NULL, 'Dr. Elena', 'Female', NULL, '15', NULL, 'default.png', NULL, NULL, '1', NULL, 'Cruz', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '9', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'secretary.caingin@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Luz', 'Female', NULL, '16', NULL, 'default.png', NULL, NULL, '1', NULL, 'Mercado', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '4', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'treasurer.caingin@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Jose', 'Male', NULL, '17', NULL, 'default.png', NULL, NULL, '1', NULL, 'Ramirez', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '5', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'councilor1.caingin@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Alma', 'Female', NULL, '18', NULL, 'default.png', NULL, NULL, '1', NULL, 'Torres', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '6', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'chairperson.caingin@barangay.com', '2025-06-06 20:48:03', '2025-12-31', NULL, 'Benjamin', 'Male', NULL, '19', NULL, 'default.png', NULL, NULL, '1', NULL, 'Aguilar', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '7', NULL, '2023-01-01', NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'healthworker1.caingin@barangay.com', '2025-06-06 20:48:03', NULL, NULL, 'Nurse Rosa', 'Female', NULL, '20', NULL, 'default.png', NULL, NULL, '1', NULL, 'Delgado', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', NULL, NULL, '9', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'juan.santos.tambubong@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Juan', 'Male', NULL, '21', NULL, 'default.png', NULL, NULL, '1', NULL, 'Santos', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09171234567', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'maria.garcia.tambubong@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Maria', 'Female', NULL, '22', NULL, 'default.png', NULL, NULL, '1', NULL, 'Garcia', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09182345678', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'pedro.dela.cruz@yahoo.com', '2025-06-06 20:48:03', NULL, NULL, 'Pedro', 'Male', NULL, '23', NULL, 'default.png', NULL, NULL, '1', NULL, 'Dela Cruz', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09193456789', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'ana.reyes.tambubong@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Ana', 'Female', NULL, '24', NULL, 'default.png', NULL, NULL, '1', NULL, 'Reyes', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09204567890', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('32', NULL, 'carlos.mendoza@hotmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Carlos', 'Male', NULL, '25', NULL, 'default.png', NULL, NULL, '1', NULL, 'Mendoza', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09215678901', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'rosa.martinez.caingin@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Rosa', 'Female', NULL, '26', NULL, 'default.png', NULL, NULL, '1', NULL, 'Martinez', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09226789012', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'miguel.torres.caingin@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Miguel', 'Male', NULL, '27', NULL, 'default.png', NULL, NULL, '1', NULL, 'Torres', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09237890123', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'carmen.flores@yahoo.com', '2025-06-06 20:48:03', NULL, NULL, 'Carmen', 'Female', NULL, '28', NULL, 'default.png', NULL, NULL, '1', NULL, 'Flores', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09248901234', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'ricardo.santos.caingin@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Ricardo', 'Male', NULL, '29', NULL, 'default.png', NULL, NULL, '1', NULL, 'Santos', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09259012345', NULL, '8', NULL, NULL, NULL, NULL);
INSERT INTO `users` (`barangay_id`, `chief_officer_esignature_path`, `email`, `email_verified_at`, `end_term_date`, `esignature_path`, `first_name`, `gender`, `govt_id_image`, `id`, `id_expiration_date`, `id_image_path`, `id_number`, `id_type`, `is_active`, `last_login`, `last_name`, `password`, `phone`, `phone_verified_at`, `role_id`, `signature_image_path`, `start_term_date`, `verification_expiry`, `verification_token`) VALUES('3', NULL, 'elena.cruz.caingin@gmail.com', '2025-06-06 20:48:03', NULL, NULL, 'Elena', 'Female', NULL, '30', NULL, 'default.png', NULL, NULL, '1', NULL, 'Cruz', '$2y$10$YavXAnllLC3VCF8R0eVxXeWu/.mawVifHel6BYiU2H5oxCz8nfMIm', '09260123456', NULL, '8', NULL, NULL, NULL, NULL);


SET FOREIGN_KEY_CHECKS=1;
-- End of backup
-- Total rows exported: 746
